# astrbot_plugin_battle_report

AstrBot 战队战报插件：QQ 群约战排表 + 战报解析入库 + 跨群统计。数据存线上 MySQL。

## 改代码前必读

[REQUIREMENTS.md](REQUIREMENTS.md) 的两节，不要跳过：

- **§5 全局口径** —— 15 条横切机制（M-01~M-15）：群隔离、战队归属、玩家名解析、`0:0` 占位、判罚、替补、胜者判定、时间范围、渲染、消息收发、群属性、去重指纹、踢馆赛、月度结算、QQ 申请审批
- **§7.1 变更传导矩阵** —— 改 X 必须同时改哪些；§7.3 是「同一逻辑在多处各写一遍」的清单

## 文档规矩

**加/改功能时，两份文档必须一起改**（硬要求）：

| 文件 | 视角 | 改什么 |
|---|---|---|
| [README.md](README.md) | 使用者 | 核心功能条目、命令语法、示例、配置表、更新日志、版本徽章 |
| [REQUIREMENTS.md](REQUIREMENTS.md) | 开发者 | §6 功能清单加 F-xx；新口径改 §5；新联动改 §7；新技术债改 §10；新配置改 §11；新测试改 §12 |

逐项清单见 REQUIREMENTS.md **§9 新增功能检查清单**（含版本号三处、删配置项四处等容易漏的收尾动作）。

## 易踩的坑（详见 REQUIREMENTS.md §10）

- **统计按战队跨群聚合**（`home_team`），不是按群隔离——改统计 SQL 时别顺手加 `group_id` 过滤。同理，指纹（§5-M12）**不含 `group_id`**：换个群提交同一份战报算重复
- **改内容指纹算法 = 破坏历史去重**。已有行的指纹按旧算法算，改了算法会让同一份战报能再存一次。`tests/test_fingerprint.py` 里钉了一个写死的期望值作锚点
- **写迁移必须可重放**：`_init_schema` 没有外层 try/except，任何一条 ALTER 失败 → `initialize()` 抛异常 → `db_ready=False` → 全插件不可用。加列/索引前一律先用 `information_schema` 探测
- **战队解析只有一条路径**：`_require_home()`（必须群绑定）。别再引入配置兜底（v1.13.0 刚删掉 `_get_effective_home` + `home_team` 配置）
- **加排行列**：`_RANK_HEADERS` 改完，`rank_aligns(ncols)` 自动跟随，但 `build_ranking_cells` 的**数据行是手写定长列表**，必须手动同步
- **排行图片左侧的「战队战绩」面板**（`stats.build_team_panel`）**不走 `build_ranking_cells`** —— 那 14/15 列的契约由它独占。面板是图片独有的展示层，文字表格（`format_player_ranking`）没有它。加行要同步 `_TEAM_PANEL_LABELS` 与返回值列表两处
- **改名次口径**：唯一实现是 `stats.ranks_for()`，排行榜表格与 `/结算` 发奖金共用——另写一份会让榜上第 1 名按第 2 档发钱
- **奖金列开关**：唯一实现是 `stats.attach_bonus(rows, bonus_map)`，`bonus_map` 空就**一个 `bonus` 键都不加**——`build_ranking_cells` 正是靠「行里有没有这个键」决定加不加第 15 列。写成无条件赋值会让未结算月份也长出整列 0
- **`/结算` 是双模式命令**（`main.settle`）：`_is_manager` 之前是共用的（`_require_home`、参数解析、`settle_month_range`），之后分叉 —— **写路径**（管理员）和**只读查询**（其他人）。**加任何写操作必须放进 `is_admin` 分支内**，放到分叉前会让群员的查询也写库。两个回执 `format_settlement` / `format_settlement_view` 的抬头**刻意不同形**（「结算完成」/「结算查询」），行体共用 `stats._settlement_lines`
- **群消息的结算 @ 只在「该月首次结算 / 获奖名次变了」时发**：判据是 `stats.settlement_awards_changed`（比 `(rank_no, player)`，**不比奖金**）。⚠️ `main.settle` 里**读旧记录的 `get_settlement_entries` 必须在 `set_settlements` 之前** —— 挪到后面永远比不出变化，每次重跑都会 @ 全群。公告文案是 `stats.settlement_announcement` 的**分段**（`("at", 名)` 不能拼进字符串，否则 QQ 上只剩字面的「@名字」）；取 QQ 走 `database.get_qq_ids_by_names`，它按 **`users.name`（展示名）** 查而不是 `player_ids.player_name`（参赛ID）—— 榜上的 `player` 是 `COALESCE(u.name, d.player_a)`
- **`/重置结算` 只做一件事：`database.clear_settlement` 删本队本月那几行**（`DELETE`，不是 `UPDATE` 置标志位）。它是**纯管理命令**（`_is_manager` 硬拦，没有 `/结算` 那种群员只读分支），返回 0 行 = 该月本就没结算过 → 回「无需重置」而**不是报错**。`clear_settlement` 一旦被改成带附加写操作（连删用户、改积分），`/结算` 的双模式分叉就白设计了
- **月份缺省 = 上个月**：唯一实现是 `battle_report_parser.settle_month_range(month: int | None = None)`（`12 if now.month == 1 else now.month - 1`），`/结算` 与 `/重置结算` **共用**它——两边的 `key` 必须由同一个函数产出，否则「重置 8 月」会把 7 月的记录删掉。⚠️ 「当月未结束」的拦截只在 `/结算` 的**写路径**里，`/重置结算` **没有**这个检查（重置一个未过完的月无害）
- **面板的守馆/守馆首轮/踢馆三行是「各自赚了多少」的原始分量**（`_ceil_div3` + `attack_points`），**刻意绕开带 10 分封顶的 `raid_defense_points`**。别"顺手修"成 `raid_defense_points`——封顶只体现在面板最后一行「积分」上
- **`is_kof()` 是判定规则的唯一实现**（`battle_report_parser`），别在别处重写 `"人头" in rule`
- **文案风格：改「句子」，不改「数据」**。用户可见的叙述句统一猫娘口吻（中等浓度：句尾「喵」/「喵～」，关键回执配一个颜文字，不自称「人家」不称「主人」）。**绝不能动**的：表格表头 `_RANK_HEADERS`/`_BONUS_HEADER`、面板标签 `_TEAM_PANEL_LABELS`、命令名与参数、`lineup.generate_template` 的战报模板与 `main._FORMAT_EXAMPLE`（**对局行双空格是 `battle_report_parser` 的解析契约**）、`format_duel_results`/`format_raid_results` 的逐场数据行、CSV 表头、`/查ID`·`/管理ID`·`/群列表`·`/战队列表` 中的 ID、角色归属与群号数据、命令索引中的命令语法。⚠️ **「结算完成」/「结算查询」的措辞是判据不是文案** —— 它们承担「写过库」与「只读」的区分，别当文案改得同形（§5-M14）。测试的守卫方式：叙述句断言「含语气词且关键信息仍在」，数据行断言**逐字不变**
- 积分/胜率/玩家名解析在 Python 与多处 SQL 里各写一遍（§7.3），只改一处会让数据自相矛盾
- `min_games`（排名门槛，在 SQL 的 `HAVING` 里）与 `min_duels`（提交前置条件，在 `main.py`）是**两件事**，别混

## v1.16.0 权限与参数约束

- `/绑定战队`、`/群聊属性`：超管可设置任意群；其他人必须是对应战队管理员，QQ 群主/群管理和 AstrBot 全局管理员身份本身不提供这两项权限。
- `_is_manager` 包含超管、AstrBot 全局管理员、本群绑定战队管理员和 QQ 群主/群管理；战队管理员仅在本队已绑定群内继承插件管理权限。
- `/发送` 先拒绝私聊，再检查群启用、属性为战报群及绑定。引用、批量、踢馆均共用此入口；不再读取 `allow_private_chat`。
- 参赛 ID 用 `command_args.py` 的统一解析，允许引号、保留 ID 内空格。别重新用 `payload.split()` 拆名字。
- `team_admins` 按 `(home_team, qq_id)` 授权，schema v18；设置名单是覆盖，必须保留撤销与查看入口。

## v1.17.0 流程帮助

- v1.17.2：用户可见的固定示例使用虚构队名 a队/b队、云玩家/萌新/遗老等 ID；空格 ID 使用“示例 玩家”。修改示例名称时保持命令语法、战报字段与对局分隔格式不变。

- 默认群名仍是友谊群，不重命名、不增加群名别名。默认用途不等于已经明确设置属性。
- v1.17.1：普通帮助和全部流程只展示操作流程，不夹带开通步骤或默认/未设置状态。需要群设置的命令缺项时或显式请求设置帮助时，再展示简短引导；不展示 super_admin 配置说明、授权示例或超管功能入口。
- 默认帮助及开通提示统一由 `help_guide.py` 生成；`stats.render_help` 仅保留为 `/帮助 命令` 的索引。
- 友谊群的排表/记录/追加轮次不新增绑定要求；依赖战队的 `_require_home` 和 `/发送` 检查战队及明确群属性，缺项返回设置流程。导出也必须走同一前置检查。
- `get_group_chat_type_setting` 用 None 区分尚未设置；`get_group_chat_type` 仍返回默认友谊群，不得为了判断是否设置而偷偷写入默认行。
- `/绑定战队` 和 `/群聊属性` 成功后发送对应流程；帮助预览不得写入设置。数据库不可用时帮助显示通用预览，不谎报本群未绑定。

## v1.18.0 QQ 申请审批

- `RequestReviewFilter` 只匹配 OneBot 原始请求、严格匹配的私聊 QQ 邀请卡与明确的同意/拒绝短回复；不要注册会唤醒所有消息的监听。
- 好友与入群邀请通知私聊发送给 `super_admin`。审批及 `/申请列表` 仅允许该 QQ 私聊操作，不复用战队/群管理员权限，也不依赖 MySQL。
- `request_review.py` 原样保存并回传 flag；使用平台 ID + 机器人 self_id 隔离申请，不能拿 QQ 号或申请编号替代 flag。
- `request_reviews.json` 先持久化处理中状态再调用平台，处理完成后持久化结果；引用消息必须匹配已发送通知。处理超时/重启中断转为需核实，不自动重复执行。
- v1.18.1：同时读取原始 reply 与 AstrBot Reply；ID 不匹配时核验机器人发给当前超管的原通知，不因组件丢失而退回唯一 pending。由 main 注入 AstrBot logger；aiocqhttp NetworkError 属于 OSError，需归类为结果未确认。
- v1.18.2：确认 SnowLuma 后才从实时原始邀请卡的 groupcode/msgseq 建立独立申请，格式参照上游 formatGroupRequestFlag；不改写原 flag、不扫历史、不自动重定向旧编号。新卡片替代同群同邀请人的旧 pending 为 superseded，保留已确认/未知结果。QQ 明确返回 120162004 + already agree msg by self 时同步 approved，即使用户点拒绝也不能记成 rejected；120161001 等其他错误仍需保留失败，兼容路径需实机验证。
- 不自动同意申请，不处理群成员加群请求，不把群内“同意”当审批。
- v1.18.4：群邀请实际结果落盘后，使用原连接私聊原邀请人，通知实际同意/拒绝及群号。通知异常只提示超管手动告知，不改变审批状态；重复处理不重发。不要把通知异常当审批失败或向好友申请人发送入群结果。

## v1.19.0 排行点评

- `/排行` 各分支先发原图表或文字，再调用当前会话的模型点评。开关 `ranking_ai_comment` 默认开启；无数据不调用。
- 复用当次查询的月份、范围及 stats 展示函数，不新查榜单、不重算积分/名次。传入全部已展示条目，图片截断行不能出现在点评输入中。
- 不导入聊天历史，不提供工具或修改会话；模型失败只影响点评，不能回到排行查询失败分支。人格和生成总计限时 30 秒。
- `ai_persona_id` 是插件全局通用的人格选择，统一调用不接收 event 的 `_ai_persona_prompt()`，不按群读会话人格。模型使用当前会话配置，不新增模型选择项。固定插件文案的猫娘语气要求不适用于 AI 点评。
- v1.19.2：未配置/禁用/不可用人格时静默跳过点评，不回退默认人格，不调用模型或发送提示。点评无「💬 排行点评」标题，简短、单段，输出合并换行并限制过长文本；其余内容和语气让 AI 自由发挥，不指定点评方向。

## v1.19.3 战报原文输出

- 排表、记录、轮次成功正文使用 `_send_report_text` 直接发送并停止事件，不再 yield 到回复整理阶段；部分错误提示也直接在正文后发送。禁群、私聊与参数检查必须在直发之前。
- `lineup.normalize_duel_spacing` 只规范轮次内对局的比分外部分隔为双空格，不压缩选手 ID 内空格，不改变头部、标记、比分或换行；模型点评的空白整理不能用于战报正文。
- 发送失败不自动重试，避免重复战报。此路径依据发送前日志已变单空格的现场证据保护输出，不宣称已确认具体是哪一个外部处理器修改了空白。

## v1.19.4 踢馆导出
- v1.19.4：`/导出 踢馆` 的类型与玩家独立解析，转发和 CSV/JSON 共用 `filter_report_outcome(..., kind=...)`。v1.20.1 起缺省仅友谊、显式踢馆仅踢馆，保留 home_team/月份/个人胜负口径与引号 ID；趋势复用解析时设置 `allow_kind=False`。

## v1.20.0 战报发送状态

- `matches.export_sent` 为人工外发标记，schema v19，历史/新战报默认 0；迁移先探测字段再 ALTER，不重算指纹或战绩。
- `/导出` 默认导出全部友谊战报，显式踢馆只取踢馆，按未发送/已发送分成独立转发包或文件；显式状态筛选与类型/玩家/胜负条件组合。`全部` 仍是胜负参数，不重置状态筛选。趋势复用解析时同时关闭 `allow_status`。
- v1.20.2：`/标记已发送 <截止战报ID>`、`/标记未发送 <截止战报ID>` 仅群内管理员，先 `_require_home`，再 `_is_manager`；只接受一个截止 ID，不再用引用/多 ID。更新本队 id<=截止 ID 的所有战报，不限月份、类型或 100 份。截止记录必须存在且属本队，否则不写。
- `set_reports_export_sent_through` 在事务内加锁核验截止记录后，以 home_team + id<=cutoff_id 统一更新；较新记录和其他队不变，重复标记幂等。导出仅查询，不自动标记。节点名称展示状态和 ID，战报正文不能塞标记或改空格。

## v1.20.4 恢复排行标准回复链

- 已撤回 v1.20.3 的 `_send_ranking_image`、排行直接 event.send/stop_event 和上传失败文字替代。排行图片/点评均 yield 给 AstrBot 标准响应阶段，保留回复装饰、TTS 和持久化等插件的框架接入流程。
- 图片生成失败沿用原文字回退；成功生成不等于已上传。`EAI_AGAIN htdata3.qq.com` 需在 SnowLuma 部署端排查 DNS，不能声称恢复回复路径就修复了网络或普通聊天。
- 回归只验证本插件图片/点评顺序、无 stop_event/直接发送及独立请求；真实第三方插件、普通聊天和生产网络仍需现场日志确认。

## v1.21.0 手机战绩卡

- `/战绩`、`/我的战绩` 走 `_record_results`：标准 yield Image，不直接发送/stop_event/调用 LLM。统计与趋势同队同日期，本队用整场趋势，个人/角色用对应 ID 且限定本队。
- `stats.build_record_metrics` 复用积分公式供图和文字回退；`chart.make_record_images` 以 900px 两列竖版展示主指标和内嵌趋势。v1.21.2 多 ID 时综合战绩与各 ID 同指标行并排，只生成一张图；每组三个 ID、组间在图内续排，长名及内部空格保留。
- v1.21.3：共享 `_trend_image` 的横轴两端对称留白，单点居中；蓝线、场次虚线与日期同一横向映射，内嵌日期按实际数据宽度抽样。
- `_trend_image` 与独立 `/趋势` 共用轴算法；嵌入图密集点位百分比错位避免重叠。空趋势与查询失败显示不同提示，图片生成失败才回退文字。
- `get_players_aggregate` 的踢馆三项次数与积分从已有集合计算结果透传，不相加各 ID 的踢馆统计。保留 schema v19、已有配置与身份权限。

## v1.21.1 活跃 ID 展示

- `get_players_aggregate.active_players` 复用已有逐 ID 的 total>0 判断，按所选月份的友谊总场次筛选，包含平局；不新增查询。
- 用户卡的 ID 列表、我的战绩明细及文字回退使用 `visible_players`；汇总和趋势仍使用完整 `players`。不解绑 ID，不丢原集合的踢馆积分；零活跃仍显示汇总，只有一个活跃 ID 不重复展示明细列。

- v1.21.2：`record` 角色查询和 `my_record` 共用 `_record_id_details`，只查有场次 ID 的明细。`make_record_images` 始终返回一个路径，综合与各 ID 横向对照、趋势位于下方，不再生成 `_ids_N` 文件。

## 安装包交付

- 更新时同时交付 ZIP。安装包根目录直接包含 metadata.yaml 与 main.py，使用 AstrBot 的安装包校验检查内容。
- `install-packages` 分支只存安装包，源码在 master；下载链接指向包文件，不使用 GitHub 自动生成的源码归档替代安装包。

## 用户提示风格

- v1.17.8：提示只讲结果和必要下一步，删除括号里的重复原因、内部处理过程或多余例子。不要为简短句子补一段解释。
- 按具体文案修改，不能用正则统一删除括号。战报 ID、月份/战队范围、权限、单位、颜文字及 `(替)`/`(规则)`/`(馆主)` 等格式标记仍要保留。
- 结算查询使用「结算查询」抬头与写入区分，无需再附带「这次一个字都没改」之类尾注。命令语法及真实用户数据不受文案清理影响。

## 测试

```bash
pytest tests/   # 默认跳过数据库模块，无需 DB
ASTRBOT_TEST_MYSQL_ENABLE=1 ASTRBOT_TEST_MYSQL_PASSWORD=<测试密码> pytest tests/  # 独立测试实例
```

数据库测试只使用独立的 `ASTRBOT_TEST_MYSQL_HOST/PORT/USER/PASSWORD`（默认本机），
**不继承插件配置**。必须显式设置 `ASTRBOT_TEST_MYSQL_ENABLE=1` 才启用；会创建并删除
`astrbot_battle_report_test_<进程号>`。使用隔离测试实例，勿配置生产服务。

## v1.22.0 多月份结算与 QQ 群公告

- `_parse_settle_args` 返回月份列表和一个统一名次数，支持空格/逗号/中文分隔，去重；不写月份仍是上个月，复用 `settle_month_range` 的跨年口径。重置只接受一个月份，多月必须拒绝，不能静默选一个。
- `settle` 先校验所有日期、准备所有可结算月份，再由 `set_settlements` 在单一事务覆盖本队各月；空榜月份跳过、不删旧快照，错误/取消回滚全部。单月 `set_settlement` 委托同一实现，schema v19 不变。
- 每次管理员成功提交后调用本群 `_send_group_notice` 一次（包括名单未变），正文由 `format_settlement_notice` 复用同份快照生成，含各月明细与每人合计。普通成员只读，不能发公告或写库。
- 群公告使用当前事件机器人/群号，20 秒限时，无自动重试；需要机器人 QQ 自身公告权限。公告失败/超时与已保存结算分开回执，不伪装成结算失败。群消息 @ 继续按名次变化触发、同次按人去重，QQ 查询失败降级为文字提醒。

## v1.23.0 LLM 排表工具

- 仅注册 `battle_report_lineup`，Args 描述为 `lineup_text(string)`；event 由 AstrBot 注入，不向模型开放群号/权限参数。使用 `filter.llm_tool`，不依赖全局人格配置或单独请求模型。
- 命令与工具共用 `_prepare_lineup` 的群禁用/DB/私聊检查、名单解析、名单保存及模板生成，保留引号空格 ID、默认规则、种子、TK 与双空格。工具失败返回错误文本，成功 `_send_report_text` 直发后 clear_result 并返回 None，防止执行器重发遗留结果或模型改写正文；不自动重试发送。
- 排表仍不要求群绑定/属性，不写比赛结果；仅当前群、仅用户明确给出的名单，缺项应追问。不能把其他命令顺便注册为工具。

## v1.24.0 QQ 官方等车

- `OfficialQueueFilter` 接收 qq_official/qq_official_webhook 与 aiocqhttp 的明确等车指令（含帮助别名），priority=100；OneBot 仅静默 stop_event + clear_result，不查服务、不发提示，避免转入聊天。队列操作仍仅官方平台，另验 GroupMessage 的 group_openid；不接管其他平台或普通闲聊，不新增 LLM 工具。
- `official_queue.py` 的 WaitingQueues 按 platform_id/AppID/group_openid 隔离、成员用 OpenID。后台按原持久化截止处理，单群锁、多群并行；临时文件原子替换，失败不覆盖其他群的在途引用。
- 队列 180 秒刷新，未满3人540秒、满3人重新900秒，v1.25.6 新加入按当前人数重置540/900秒、重复加入不重置、降至2人重开540秒；个人 joined_at 不随刷新重置。独立多车、一人同时一车，已在车中再开创建空车。发车只允许本车成员、至少3人，@其他参加者；到期通知全部当时成员。
- SDK直接发送 Markdown+键盘，发车按钮仅填输入框；C前缀车token避免未填群号误发车。旧车token不复用；公开战绩按本群home_team/北京时间当月，通过同份build_record_metrics得到胜率，不写统计/权限/原ID归属。
- 存档 official_waiting_queues.json；终态提醒先落outbox再发送，确认id才移除，失败延后补发。主动推送权限由用户确认已具备，默认开启；保留5分钟被动限制，不能伪报成功。卸载先取消任务再关DB，schema v19保持。

## v1.25.0 官方身份关联

- `/等车ID` 申请给原角色关联 OpenID，原 QQ `/确认关联` 一次后生效。schema v20 新增 official_user_accounts / official_link_requests，保留 users.qq_id 和 users.id，不创建替代用户、不移动参赛 ID。只存10分钟一次性码的哈希，已有映射不覆盖；原QQ可解除自己的全部关联。
- `_identity_qq` 是平台身份统一入口：OneBot用原QQ，官方用AppID隔离的已验证OpenID映射到原QQ。所有 own-ID、改名、我的战绩及超管/战队管理判断共用；`_is_super_admin` 现为异步，全部调用必须await。按用户最新要求继承原QQ已有全部插件权限，不改event.role或QQ服务器权限。
- 验证前不能写 users.qq_id=OpenID，不信任公开角色名和旧JSON展示别名授权。源角色QQ归属变化立刻失效，AppID跨连接切换可复用，同名其他bot不共用。未绑定官方群可只为认证找唯一原QQ，不自动设置群战队或兜底统计。

## v1.25.1 自定义过滤器注册

- 单个过滤器用 `@filter.custom_filter(OfficialQueueFilter)` 传类，不要传实例；v4.27.3 内部自行用 raise_error 构造。RoundCommandFilter 和 RequestReviewFilter 同样传类，审批优先级100保留。
- tests/test_main 的桩必须在装饰阶段实例化并校验 CustomFilter，禁止退回无操作 lambda；新增“旧实例写法必须报错”与三处过滤器构造参数回归。发布包除 metadata 检查外，使用目标 AstrBot 实际注册函数做全插件模块导入检查，不将这个隔离检查当作 QQ 实机验证。

## v1.25.3 等车面板

- 头像只用 scope AppID + 原始 OpenID 的官方 CDN 地址，32px 内联图片，不要求先关联 QQ。姓名/已等待时间使用正文色，其余面板说明使用 Markdown 引用次级色，不写 HTML 字色标签。
- 自动清理展示 deadline 的实际剩余时间，广播间隔展示 REFRESH；不能把文案调整变成计时或权限变更。

## v1.25.4 友谊等车名称

- 主入口 `/友谊等车`，帮助 `/友谊等车帮助` 和 `/帮助 友谊等车`；原入口与旧面板按钮保持兼容，解析归一到原内部动作。存档、scope、token、配置键不改；加入、离队、发车及等车ID 指令沿用原名。OneBot 对新旧命令均静默终止。

## v1.25.5 官方端仅友谊等车

- OfficialQueueFilter priority=10000 接收官方两种接入的全部消息；处理器白名单只执行等车相关命令，v1.26.5 起其他消息在服务检查前只过滤本插件已匹配的处理器并禁用默认LLM，保留第三方插件分发；无第三方处理器才 stop_event + clear_result。OneBot 等车仍静默终止；v1.26.6 其他QQ群命令只关闭默认LLM，插件分发和普通聊天保留。
- lineup_tool 对官方平台提前终止并返回 None；身份表、原账号权限数据与原队列不删除、不迁移，账号管理等原功能在 SnowLuma 使用。

## v1.25.6 新人入队

- 实际新增成员时，快照加入前本车 members 作为提醒对象，成员/按当前人数重置的 deadline/outbox 在同一 edit 原子保存；空车无旧成员不发空提醒。保持旧成员 joined_at 和 next_refresh。重复加入、重放或被拒绝的跨车加入不新增提醒或延时。
- 入队提醒复用持久化 outbox 及既有重试路径，失败不回滚已提交成员/计时；重启仍按保存的截止、收件人和 retry_at 补发。

## v1.26.0 友谊等车 v2（覆盖旧版规则）

- REFRESH=240，GATHER_TIMEOUT=READY_TIMEOUT=600。建队600秒，仅首次满3人设置粘性 ready 并重新计600秒、专属 @3人接友谊；之后进出和再次满员都不改deadline。入队@旧成员、离队@剩余成员，通知和状态同一原子edit提交。
- 多车一个panel，房间只有一个 next_refresh，车只有独立deadline；用户一群一队，离队/发送群号/解散默认本人队伍。统一2行3按钮，成员一逻辑行、正文标题、计时同一行，胜率不展示且不查询。
- 群名片优先，没有时用QQ昵称；原生@保证通知，旁附cmd-input填@姓名（不是原生@令牌）。群号采用用户已同意的点击填入方案，不宣称能打开QQ原生号码弹层。
- JSONv2新增房间广播/编号日期、车日期和创建者；v1可重放原子迁移，旧截止不复活。每日北京时间重置展示编号但token不重用，跨日裸数字歧义拒绝。保留原schema20与身份关联，官方仅等车、OneBot等车静默策略不变。

## v1.26.1 入队后简写

- `/离队` 和 `/解散` 分别归一到原离队/解散动作；按钮数据使用简写，旧指令仍兼容。普通离队/解散和发送群号自动按 uid 定位本人队伍，不要求车号；只有加入特定车次需要选择。不得回退操作别人的唯一队伍。

## v1.26.2 帮助与群号原生文本

- 对外按钮和推荐指令统一“等车帮助”与 `/等车帮助`，旧长名称兼容。
- 覆盖 v1.26.0 的群号填入方案：发车先 Markdown @ 通知，再单独 msg_type=0/content=纯数字，不给群号套 cmd-input、Markdown或模板；不要手工伪造下划线或承诺未实测的客户端号码弹层。
- 两条通知同一事务落 outbox，数字 after=前条id，前条确认后才发。各自确认/移除，数字失败只重试数字。严格匹配旧待发发车链接并原子转换，保持 JSONv2/schema20。

## v1.26.3 成员姓名原生显示

- 覆盖旧版“原生@后再拼姓名cmd-input”的做法：通知按uid去重只保留原生@；面板也用原生@呈现本群名称，不显示缓存QQ昵称。面板广播会带原生@，应向使用者说明这个行为。
- 入退队和发车正文不再拼缓存人名，避免绕过上述显示规则；保持原收件人、纯数字群号发送和队列计时。历史names字段保留但不用于标签渲染，不宣称原生@点击能自动填入输入框。

## v1.26.4 面板与通知标签分开

- 覆盖v1.26.3的面板标签：面板show=名字、不额外加@，text=@名字+空格，使用cmd-input而不是原生成员@；面板更新/广播不能因此@队员。姓名使用当前可用的群名片优先、QQ昵称兜底缓存，不宣称能读取QQ客户端渲染的群名片。
- 仅面板改变，入退队/满员/发车/解散通知仍按uid保留一次原生@且不拼额外姓名链接，纯数字群号发送保留。点击填字不能宣称等于生成原生@对象。

## v1.26.5 第三方插件分发

- 官方端非等车消息不得全局 stop_event 拦住音乐等其他插件。原地过滤 activated_handlers 中本模块或绑定当前实例的处理器，保留 official_queue_cmd 自身防止遍历下标移动；不重新排序、不清除第三方参数、不直接调用第三方处理器。
- should_call_llm(True) 只关闭框架默认聊天，不关闭其他插件自己的 LLM 请求。没有其他处理器时静默停止；队列命令仍独占，OneBot 平台规则保持不变。
- 参数解析早于处理器执行，能收到参数错误不代表正常命令已经执行。现场 /登录Q音、/查歌词、/点歌 无回复由此前全局停止引起，修复后音源及真实官方发送需单独验证。

## v1.26.6 QQ群命令隔离

- OfficialQueueFilter 的 OneBot 分支另匹配群命令：原始顶层 Plain 中的斜杠优先；裸形式只读全局注册表的标准命令/组及别名，only_activated=False，不调用第三方过滤器，不缓存重载后的过期名单，不将被引用的命令当本条命令。
- 非等车 OneBot 群命令仅 should_call_llm(True)，不 stop/clear、不改已匹配处理器及参数、不查DB/队列。这样未知命令也不会进入默认LLM/活跃对话，已启用插件和主动AI功能保留。
- 不要求 chat 前缀；普通聊天、私聊和其他平台不新增限制，官方群仍沿用原范围。必须在双连接的配置中均启用插件。未知自定义裸指令需显式加/。

## v1.27.0 平台指令配置

- platform_command_profiles 使用命名模板列表，精确匹配 get_platform_id，首条匹配生效；空目标不匹配，未配置保留旧范围。目录和别名只在 platform_policy 维护，新增指令必须同步 schema 选项并通过目录完整性测试。
- 构造期用 get_handlers_by_module_name 给本插件所有消息处理器前置权限过滤，包括暂时禁用的处理器；跳过路由器，重装先移除旧标记，回调读取当前实例配置。拒绝必须先于参数转换。运行期只移除本插件未开放的处理器，保留当前路由器避免迭代下标跳过第三方；不得全局 stop 别的插件。
- 队列动作/旧入口归一到同一权限，第N轮按稳定函数名识别；AI排表工具共用排表权限。等车仍仅官方，确认/解除原QQ关联、审批/列表/刷新及群成员导出仍仅OneBot。配置不能绕过角色/群校验或触发数据库/队列迁移；普通聊天和已有队列计时/通知不改。

## v1.27.1 呼叫全体

- 等车共享键盘新增第三行“呼叫全体”与同名命令，原生 qqbot-at-everyone 摇人友谊；平台目录和schema选项必须同步，OneBot静默。
- 房间call_all_until可选字段、1800秒冷却；所有用户/车次共用，按连接/AppID/group隔离。v1.34.1起仅有效成功回执后持久化冷却，失败／超时／取消不占冷却，不进outbox、不自动补发，允许用户新消息重试。跨日/散队/重启不清零，不改变车次及广播计时。
- QQ群管理员和每日全体额度由平台限制，SDK文档注明每群每天1次，不能把插件冷却描述为实际每30分钟均可@全体。旧JSONv2和MySQL schema20保持。

## v1.27.2 呼叫全体完整面板

- 呼叫全体通过panel的单次announcement参数加入原生全体标签和邀请，复用全部车次/成员/计时/按钮渲染；普通交互及广播不传announcement，不能重复@全体。空房提示没有队伍，不隐式建车；30分钟冷却、清理和广播时钟不改。

## v1.27.3 冷却隐藏呼叫按钮

- panel统一按渲染时刻与持久化call_all_until控制键盘show_call_all，冷却中去除第三行，保留原六按钮；到期后下次面板刷新恢复。呼叫结果、查看、交互、广播和重启均共用规则，文字命令及旧按钮仍保留冷却校验。

## v1.28.0 外部战报核对

- WebUI在pages/report-comparison，官方后台bridge+web SDK和登录授权；不自开端口，不在QQ暴露管理接口。任务只读快照、原文文本渲染，关闭先取消任务再关DB。
- report_site/report_comparison与离线CLI共用逻辑；只比较friendly，按home_team跨群。网站发布时间与正文比赛日期分开。完整分页和唯一ID校验失败不得输出局部差异。
- 比较键包含规则、轮内顺序、原ID内部空格、替补和判罚，按对局实际战队侧对齐；不得改已有report_fingerprint。网站未检出与同日同地点内容不同只是待核，不自动改库/合并/删报。
- 最近20次任务JSON保存在data_dir/report_comparisons；最多93天、200页/10000条、5分钟。重启中断不自动重跑；只允许固定战报站HTTPS，禁止跨站跳转及匿名API访问。


## v1.29.0 云端归档、本地列表与 QQ 发送

- schema21 的 cloud_battle_reports 与本地 matches/duels 独立，网站 ID 主键，完整抓取校验后事务 UPSERT，同 ID 更新原记录；不进入本地战绩，不随20次核对历史淘汰。旧 INT users 库先完成 v10 BIGINT 迁移，再建官方身份外键表。
- 后台三Tab，核对仍仅友谊，本地列表可选全部/友谊/踢馆，云端列表直接读归档。source+ID跨页去重；本地再校验home_team。准备发送由服务端重读正文，禁止信任客户端正文。
- QQReportDispatch仅aiocqhttp原生私聊合并转发；自定义QQ或目标战队指定管理员，确认时再校验名单和bot QQ。先冻结预览、显式确认，typed text节点；最多200份/20收件人/8MiB，每50节点分包。
- 回执按收件人/包落盘；有message_id才成功，unknown不得自动/手动重试，失败/未发送可显式重试；重启不重放。预览30分钟/重试24小时、单请求25秒/批15分钟，发送历史保留20批及活动批。不得修改人工export_sent；关闭发送/核对失败仍清理本实例路由，然后关DB。
- 新测试test_report_dispatch与可选test_report_archive_mysql；浏览器使用真实AstrBot v4.27.3 bridge/Web SDK+隔离MySQL+模拟OneBot，不声称真实QQ或线上战报站已验证。


## v1.29.1 动态轮次唤醒

- RoundCommandFilter 通过即由框架自定义唤醒，AstrBot 只保证 is_wake，不保证 is_at_or_wake_command。round_cmd 不得再拿 @/前缀专用标志阻止已匹配指令，也不强制改写该标志。平台前置过滤、群/DB/历史检查和原配对/输出流程保留。
- 入口回归必须覆盖中文/数字、斜杠/裸命令、is_at_or_wake_command=False。真实框架验证应从 WakingCheckStage 进入，不预设该标志为True，避免此前只直调handler漏掉边界。


## v1.29.2 WebUI 全文与复制

- 默认/首位本地战报，核对第二、云端第三，初始化不自动切到历史核对。列表直接呈现body全文，纯textContent/pre-wrap，不截断、压空白或执行HTML。
- copyButton共用于列表/弹窗；同步用户点击的textarea+execCommand兼容opaque iframe及HTTP，当前dialog内放临时字段以免焦点被困；移除字段、恢复焦点/选择，备选Clipboard API。只有成功才回执已复制，全失败明确反馈；不能放宽iframe权限。
- 浏览器验证必须使用真实sandbox属性，复制后真实粘贴逐字比对，而非只断言按钮文案；另覆盖备选API/拒绝、临时字段清理、手机布局与原跨页发送行为。数据库schema21和QQ指令不变。


## v1.29.3 固定分页

- 两侧箭头按当前Tab代理原分页按钮，不复制页码/范围逻辑。syncSidePaging共用底部边界、当前数据与加载状态，比较加载按sequence在finally释放；切Tab/加载/失败也同步，无数据及首末页禁用相应方向。手机预留边缘空隙，不遮正文。
- 验证三Tab路由、跨页勾选、首末/单页、固定滚动位置和手机边界；不改数据库/QQ接口/框架iframe权限。


## v1.29.4 容器外侧分页与页码栏

- 覆盖v1.29.3的浏览器边缘定位：report-layout grid为左右轨道留位，rail-controls在容器内sticky，控件不得遮正文或回到viewport两边。右轨道按页码列/下一页箭头排列。
- 页码列原生滚动，最多10行，低屏进一步限高；滚动边界隔离正文。pagingState以当前响应的total/offset/limit派生页码，jumpToPage走原查询加载，syncSidePaging统一同步禁用/高亮/作用域；切范围重建页码但不清选择篮。当前页可见只调整页码列scrollTop，禁止scrollIntoView拖动全文。
- 验证超过10页的真实滚轮和直跳、当前页、宽屏容器相对位置、切Tab/恢复数据、跨页选择及手机不遮正文。数据库/QQ接口不变。


## v1.29.5 动态处理器被运行期路由误过滤

- handler.handler在AstrBot加载后是partial(raw, instance)，没有__name__；round_cmd显示名又改为/第N轮。权限解析不能只取callback.__name__或显示名，否则匹配/唤醒成功后仍被activated_handlers路由静默移除。
- handler_command优先以精确模块前缀验证的handler_full_name解析原函数名；缺元数据时解包partial/__wrapped__并防循环，最后保留普通handler_name兜底。不得根据用户消息绕过原平台配置或放开未知回调。
- 测试必须包含StarManager实际partial绑定和initialize显示名修改，再进唤醒/分发；仅手写bound method无法覆盖部署状态。重复重载时前置过滤器需指向新实例。


## v1.29.6 全宽战报、等高卡片与胜负筛选

- 覆盖v1.29.4有宽度轨道的实现：report-layout左右grid轨道0宽，侧栏用外侧偏移，整个body统一留操作边距。搜索/选择篮/战报必须等宽；卡片同排stretch/100%等高，不截断原文。html保留overflow-y:scroll和stable槽位，空数据不产生水平抖动。
- WebUI全部/胜场/负场先筛选再COUNT/分页。本地以home_team/已存winner且确实参赛为准，云端以site_team及网站winner_site/loser_site为准；未知不算负场。可选outcome默认all，数据库schema21不变。
- 核对GET只过滤已完成结果，任一侧符合保留整组，完整分类统计/JSON不变，切换筛选重置页码并保留选择篮。新增site.loser用于网站筛选，旧历史可按已解析双方兜底。
- 验证MySQL的总数/页码/类型组合，浏览器等宽/长短同排等高/空数据几何/各Tab筛选与不重抓，以及复制和发送链路。


## v1.29.7 切换数据时的垂直稳定

- 本地/云端加载前不可先清空旧卡片，否则文档高度塌缩导致scrollY和sticky轨道跳动。保留旧节点至成功响应原子替换，旧节点inert/aria-busy且翻页禁用；最新sequence负责解除，失败清旧节点并明确错误。
- 短列表/空结果保留视口最小高度，让sticky有足够停靠空间；右轨道固定页码/箭头两列，页码隐藏也不移动箭头。不保留永久旧长页高度，也不强行scrollIntoView或回写全页scrollY。
- 测试需阻塞API，在请求过程中而非只看请求后测量rows/scrollY/轨道矩形；另测短页、单条、空数据和既有复制/发送。独立外部入口尚未实现，不能在文档中把反向代理示意说成可直接公开现有HTML。


## v1.30.0 独立战报入口

- 原Pages及bridge不改；scripts/export_report_webui.py只导出六个静态文件，输出必须位于插件目录外且新建或为空，目录0755/文件0644供Nginx读取，不导出数据库配置或凭据。
- 独立适配只允许同源固定comparison API，使用原AstrBot管理员及2FA、内存JWT/后端HttpOnly Cookie；不把token写storage/URL、不允许公开HTTP登录。401重新登录后不得自动重放POST，退出后清空页面。
- Nginx仅代理登录／退出和插件核对前缀。后端仍依赖AstrBot在线，不自开插件端口、不提供匿名API或独立战队账号，不把前端筛选描述为服务端授权。模板、导出器、独立指南及README/REQUIREMENTS同步。


## v1.30.1 自动独立入口

- 默认在原后台端口/battle-report/自动挂载，构造期热安装、on_astrbot_loaded冷启动；APP._app与core_lifecycle.star_context必须匹配当前context，不挂错旧core。无新监听端口，不写核心／Nginx／Docker配置。
- SPA兜底前插入精确前缀，只替换本插件标记旧路由，关闭按对象身份移除本实例，不能删新实例或其他插件路由；兼容失败保留Pages，卸载失败仍清任务／DB。只公开六个静态文件，不修改API鉴权或后台中间件。
- build_assets为自动挂载和手动导出唯一静态构建路径。内置HTML标记沿用后台HTTP／HTTPS；覆盖v1.30.0的内置登录协议限制，手动独立静态站仍要求HTTPS／回环。JWT及401不自动重放规则不变。


## v1.31.0 超时补发与战队网页登录

- 官方队列JSONv2可选late_cars：曾满3人的车超时保存当时members和eligible；只在原scope、发起人未加入新车时允许补发一次，原子消耗整辆快照后走原outbox+数字after。实际加入新车同事务清旧eligible，离队不恢复；未满员／人工解散／已发车无补发，不复活活动车或延长计时。
- WebAccounts独立密码／QQ一次性码，仅由原OneBot私聊QQ及当前team_admins证明身份。密码账号后台管理，不把网页密码给LLM，不在配置或日志写明文。PBKDF2／0600／原子回滚，码／会话只存内存哈希，revision／TTL／注销／停用／重启和关闭期间的在途哈希工作都需守卫。
- 默认入口新增4条路由含auth与team API，核心API仍要求原JWT；插件会话不得签发核心JWT或调用后台。团队请求绑定ContextVar，QQ与角色来自服务器；查询本地home_team／云端服务端归属、核对历史／取消／JSON下载、目录、冻结发送／重试与每包都检查当前授权。不能只在前端隐藏战队。密码账号停用不等于撤销QQ授权，需在文档和按钮明确。
- 发送plan.team_qq和cloud access_teams只由服务端生成；QQ两方式同owner共享发送历史，跨用户拒绝；按QQ／创建者分别保留20次，原后台核对共享原上限。撤权／DB异常停止未发包，已发或unknown不重放。
- Cookie限定/battle-report且HttpOnly／Strict；HTTPS或转发HTTPS加Secure，内置HTTP仍沿用后台。身份变化清正文／选择／凭据并拒绝旧generation响应，401重新登录不得自动重发操作。原Pages原后台可管理密码账号，静态导出／Nginx模板同步新前缀。新命令同步catalog／schema options和labels／帮助及指南。


## v1.31.1 管理员账号自动配置

- 设置战队管理员提交后自动补齐QQ密码账号，启动与本人私聊取码也补齐。重复授权、跨战队及重启不重置已有账号、密码或停用状态；DB授权和本地落盘分开回执，文件失败不关闭数据库或阻断QQ码。
- 未改初始密码由每安装随机密钥和账号UUID经HMAC派生，密钥是可恢复初始密码的敏感凭据，0600原子保存且不导出／日志展示。改密清标记，旧手工账号兼容，缺密钥的新初始账号拒绝载入。本人仅OneBot私聊取自身默认密码，群不发密码；原后台可显式查看，关闭／切身份清除并丢弃迟到响应。
- 网页不再手工创建／删除账号，仅同步／初始密码／重置／启停。当前管理员表始终是授权来源，停用密码不等于撤销QQ码权限。


## v1.32.0 网页队伍／队员管理

- WebManagement六条API必须在解析和DB操作前require_master；团队密码／QQ码即使是本队管理员也拒绝，不信payload.role。原核心插件22条路由保持绑定ComparisonWebUI供重载清理，独立挂载仍4条。
- 战队／角色／ID查询分页前限定范围，成员编号JSON字符串。管理员expected旧名单、角色expected原名QQ、ID expected_owner在_identity_cursor同事务内核验，避免覆盖原QQ命令或网页并发修改。
- 角色QQ变更原子删除该角色官方映射／待确认请求，失败回滚；不改变战队管理员表。ID只可绑定本队已有记录及本队角色，网页转绑需确认，不造新ID／删除角色／改历史对局。
- 前端两Tab默认hidden且只认master，管理时隐藏原战报布局，切身份清表单／名单／弹窗及旧异步响应。README／REQUIREMENTS及网页登录指南同步。


## v1.32.1 管理员成员标签

- 设置管理员默认从本队角色挑选并以QQ去重的可移除标签保存；无QQ角色禁选，无对应角色时手动添加单QQ，不写角色归属。保留未关联角色的既有管理员。
- GET management/members可include_admins=1返回本队管理员快照，仍先require_master，既有响应默认不变。使用原列表POST／expected比较／自动建号，不新增路由或SQL。
- 候选搜索分页不清选择，切战队清旧草稿，首次快照成功才允许保存。关闭／切身份清标签和候选，拒绝旧序号／旧target／已关闭弹窗的响应；Enter在搜索／单QQ字段不误提交授权。


## v1.33.0 一周会话与HTTPS

- 覆盖旧8小时／内存会话与内置HTTP例外。战队会话固定7天，摘要、QQ、账号版本、截止写入0600原子账号文件v1可选sessions；不保存原始令牌／明文密码。close不擦磁盘会话，码仍仅内存。登录／退出／改密撤销落盘失败不可伪成功；更新账号与会话删除同一次保存。撤权每次重查，异步后再次检查并发停用，恢复不放宽战队范围。
- 管理员只复用原AstrBot JWT／Secure Cookie／2FA，通常7天，不发核心JWT。非认证Cookie记录最近成功登录类型，恢复失败不自动切换其他身份；不存密码或令牌到浏览器storage或URL，不重放401后的POST。
- 公网独立页需HTTPS；auth／team API及密码查看重置在后端也检查。仅可信本机／内网代理可用XFP，回环HTTP仅本机／SSH。原核心认证／中间件不改。IP证书脚本只生成配置和受限私钥，需用户部署Nginx并在设备信任CA；无自动端口或系统更改，不以base64／哈希冒充传输加密。


## v1.34.0 每日友谊胜场检查

- friendly_audit唯一阈值DAILY_WIN_LIMIT=3；同日同对手双方各3胜，3:3不超限，不按duels计数。get_daily_friendly_counts仅home_team跨群、比赛DATE及friendly，全月预聚合后筛选分页；未知胜者／不参赛／同队记录只提示未计入，不算负场。
- friendly-limits及friendly-limits/reports先require_query检查当前QQ授权，明细还限定月份内day与opponent、home_team和friendly有效胜者；不得用公开对手名访问对方全部战报。原核心插件24路由、独立入口仍4挂载。原文复用local_record及copyButton，禁止写库／改统计或从云端算本地胜场。
- 新Tab默认北京时间本月，独立于旧Tab的上月默认；默认仅看超限，可看全部。分页复用容器侧轨道。读取失败不显示无超限，加载保留节点但inert；关闭／切Tab／切身份必须拒绝旧响应，清汇总及明细。纯逻辑、鉴权、真实SQL和实际SDK／独立入口浏览器成套验证。


## v1.34.1 呼叫全体成功后冷却

- 用户要求覆盖旧的发送前预留冷却规则。仅require_receipt确认有效字符串消息ID且无错误状态后，房间锁内从确认时刻开始1800秒；错误／超时／取消／缺回执不进入冷却，不自动重试，同一事件仍去重，新消息可手动重试。
- 同条成功面板hide_call_all渲染参数隐藏按钮，不借提前写状态隐藏。成功后冷却保存失败保留内存冷却并明确日志，不把已确认发送说成失败，不重复@全体；JSONv2／旧已存截止和schema21保持。
- 现场QQ code40034142是@全体次数超限；botpy1.2.1只保留错误文字时也需识别，不能继续泛称权限不足。插件不增加平台次数。共享回执校验影响普通通知／outbox，队列完整回归、真实SDK错误类及WS/Webhook／Markdown模板边界必须一起检查。
