"""_conf_schema.json 结构测试。

两个目的：

1. **格式**：它是 AstrBot 读的配置文件、测试配置在 conftest 中独立定义 ——
   写坏一个逗号会让**所有**数据库测试在收集阶段就崩掉，且报错信息是
   「conftest 导入失败」而非「配置有误」，很难一眼看懂。
2. **防死配置回归**：`home_team`、`default_days` 都曾是「界面有开关、代码里
   没人读」的死配置（§10-3 / §10-4）。它们已随 v1.13.0 删除，这里钉住，
   免得日后又被顺手加回来 —— 界面上的每个键都必须是代码真的在用的。
"""

import json
from pathlib import Path

SCHEMA_PATH = Path(__file__).resolve().parent.parent / "_conf_schema.json"


def _schema() -> dict:
    return json.loads(SCHEMA_PATH.read_text(encoding="utf-8"))


def _items(schema, prefix=''):
    for key, item in schema.items():
        path = prefix + key
        yield path, item
        if item.get('type') == 'template_list':
            assert isinstance(item.get('templates'), dict) and item['templates'], path
            for name, template in item['templates'].items():
                assert template.get('name'), path + '.' + name
                yield from _items(template['items'], path + '.' + name + '.')
        elif item.get('type') == 'object':
            yield from _items(item['items'], path + '.')


def test_schema_is_valid_json_object():
    schema = _schema()
    assert isinstance(schema, dict) and schema


def test_every_entry_is_well_formed():
    """每个配置项都要有 description / type / default，否则仪表盘渲染会缺字段。"""
    for key, item in _items(_schema()):
        assert isinstance(item, dict), key
        assert item.get("description"), f"{key} 缺 description"
        assert item.get("type") in ("string", "int", "bool", "float", "list", "object", "template_list"), \
            f"{key} 的 type 非法: {item.get('type')!r}"
        assert "default" in item, f"{key} 缺 default"
        # default 的类型要和声明的 type 对得上（bool 是 int 的子类，先排掉）
        if item["type"] == "int":
            assert isinstance(item["default"], int) and not isinstance(item["default"], bool), \
                f"{key} 声明 int 但默认值不是 int"
        elif item["type"] == "bool":
            assert isinstance(item["default"], bool), f"{key} 声明 bool 但默认值不是 bool"
        elif item["type"] == "string":
            assert isinstance(item["default"], str), f"{key} 声明 string 但默认值不是 string"
        elif item['type'] in ('list', 'template_list'):
            assert isinstance(item['default'], list), f'{key} 默认值须为列表'


def test_dead_config_keys_stay_deleted():
    """已删除的死配置不许回来（§10-3 的 home_team、§10-4 的 default_days）。"""
    schema = _schema()
    assert "home_team" not in schema, "home_team 已随严格解析删除，别再添加"
    assert "default_days" not in schema, "default_days 是死配置，已删除"


def test_min_duels_present_and_sane():
    """min_duels（§10-6）：提交前置条件，默认 3，必须 ≥1。"""
    item = _schema().get("min_duels")
    assert item is not None, "min_duels 配置缺失"
    assert item["type"] == "int" and item["default"] >= 1
    # 提示说明提交用途；排行门槛由下面独立的 min_games 测试守护
    assert "提交" in item.get("hint", "")


def test_min_games_still_present():
    """min_games 是排名门槛，与 min_duels 是两件事，别在清理时误删。"""
    assert "min_games" in _schema()


def test_new_install_does_not_assign_author_super_admin():
    assert _schema()["super_admin"]["default"] == ""


def test_private_submission_switch_is_removed():
    assert 'allow_private_chat' not in _schema()


def test_ranking_commentary_is_enabled_by_default():
    item = _schema()['ranking_ai_comment']
    assert item['type'] == 'bool' and item['default'] is True


def test_plugin_persona_selector_defaults_to_no_commentary():
    item = _schema()['ai_persona_id']
    assert item['type'] == 'string' and item['default'] == ''
    assert item['_special'] == 'select_persona'
    assert 'ranking_ai_provider_id' not in _schema()


def test_official_waiting_defaults_and_markdown_settings():
    schema = _schema()
    assert schema['official_queue_enabled']['default'] is True
    assert schema['official_queue_proactive']['default'] is True
    assert schema['official_queue_markdown_template_id']['default'] == ''
    assert schema['official_queue_markdown_param']['default'] == 'content'
    assert '权限' in schema['official_queue_proactive']['hint']
