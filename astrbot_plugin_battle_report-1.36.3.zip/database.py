"""MySQL 存储层（aiomysql 异步驱动 + 连接池）。

负责建库、建表、迁移，以及战报/名单的 CRUD 与聚合查询。所有方法均为异步，
通过连接池在 asyncio 事件循环中执行，不阻塞事件循环。
"""

import re
import time
import hashlib
import secrets
import json
from datetime import date
from contextlib import asynccontextmanager
from typing import Any

import aiomysql
from pymysql.err import IntegrityError

try:
    from .help_guide import FRIENDLY_GROUP, normalize_chat_type
except ImportError:
    from help_guide import FRIENDLY_GROUP, normalize_chat_type

try:
    from . import stats
    from .battle_report_parser import (
        KIND_FRIENDLY, KIND_RAID, RAID_PLACEHOLDER, report_fingerprint,
    )
except ImportError:  # 单元测试以顶层模块方式导入 database
    import stats
    from battle_report_parser import (
        KIND_FRIENDLY, KIND_RAID, RAID_PLACEHOLDER, report_fingerprint,
    )

SCHEMA_VERSION = 21

_DB_NAME_RE = re.compile(r"^[A-Za-z0-9_]+$")

# MySQL 唯一键冲突（ER.DUP_ENTRY）
_DUP_ENTRY = 1062


class DuplicateReportError(Exception):
    """同一份战报重复提交时抛出（内容指纹相同）。

    match_id: 已存在的那条 `matches.id`。并发兜底路径下若回查不到（对方刚被
    删掉），为 None，调用方需按无 ID 的文案降级提示。
    """

    def __init__(self, match_id: int | None = None):
        self.match_id = match_id
        super().__init__(
            f"该战报已存在（ID {match_id}）" if match_id else "该战报已存在"
        )


def _sanitize_db_name(db: str) -> str:
    """仅允许字母数字下划线，防止注入。"""
    if not _DB_NAME_RE.match(db):
        raise ValueError(f"非法数据库名: {db}")
    return db


class Database:
    """战报插件数据库访问层。"""

    def __init__(
        self,
        host: str,
        port: int,
        user: str,
        password: str,
        db: str,
    ) -> None:
        self.host = host
        self.port = port
        self.user = user
        self.password = password
        self.db = _sanitize_db_name(db or "astrbot_battle_report")
        self.pool: aiomysql.Pool | None = None

    async def initialize(self) -> None:
        """建库、建连接池、初始化表结构与迁移。"""
        await self._ensure_database()
        self.pool = await aiomysql.create_pool(
            host=self.host,
            port=self.port,
            user=self.user,
            password=self.password,
            db=self.db,
            charset="utf8mb4",
            autocommit=True,
            minsize=1,
            maxsize=10,
        )
        try:
            await self._init_schema()
        except BaseException:
            await self.close()
            raise

    async def _ensure_database(self) -> None:
        """以无库连接执行 CREATE DATABASE IF NOT EXISTS。"""
        db = self.db
        conn = await aiomysql.connect(
            host=self.host,
            port=self.port,
            user=self.user,
            password=self.password,
            charset="utf8mb4",
            autocommit=True,
        )
        try:
            async with conn.cursor() as cur:
                await cur.execute(
                    f"CREATE DATABASE IF NOT EXISTS `{db}` "
                    "CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
                )
        finally:
            conn.close()

    async def _init_schema(self) -> None:
        assert self.pool is not None
        async with self.pool.acquire() as conn:
            async with conn.cursor() as cur:
                # 建表（幂等）
                await cur.execute(
                    """
                    CREATE TABLE IF NOT EXISTS matches (
                        id BIGINT AUTO_INCREMENT PRIMARY KEY,
                        group_id VARCHAR(64) NOT NULL,
                        team_a VARCHAR(64) NOT NULL,
                        team_b VARCHAR(64) NOT NULL,
                        match_time DATE NOT NULL,
                        rule VARCHAR(128) DEFAULT '',
                        location VARCHAR(64) DEFAULT '',
                        submitted_by VARCHAR(64) DEFAULT '',
                        submitted_name VARCHAR(128) DEFAULT '',
                        created_at BIGINT NOT NULL,
                        fingerprint CHAR(64) NULL DEFAULT NULL,
                        kind VARCHAR(16) NOT NULL DEFAULT 'friendly',
                        export_sent TINYINT NOT NULL DEFAULT 0,
                        INDEX idx_matches_group_time (group_id, match_time),
                        INDEX idx_matches_group (group_id),
                        UNIQUE KEY uk_matches_fingerprint (fingerprint)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                    """
                )
                await cur.execute(
                    """
                    CREATE TABLE IF NOT EXISTS duels (
                        id BIGINT AUTO_INCREMENT PRIMARY KEY,
                        match_id BIGINT NOT NULL,
                        round_no INT NOT NULL,
                        player_a VARCHAR(64) NOT NULL,
                        score_a INT NOT NULL,
                        player_b VARCHAR(64) NOT NULL,
                        score_b INT NOT NULL,
                        player_a_team VARCHAR(64) NOT NULL,
                        player_b_team VARCHAR(64) NOT NULL,
                        result ENUM('A','B','DRAW') NOT NULL,
                        owner TINYINT NOT NULL DEFAULT 0,
                        INDEX idx_duels_match (match_id),
                        INDEX idx_duels_pa (player_a),
                        INDEX idx_duels_pb (player_b),
                        CONSTRAINT fk_duels_match FOREIGN KEY (match_id)
                            REFERENCES matches(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                    """
                )
                await cur.execute(
                    """
                    CREATE TABLE IF NOT EXISTS teams (
                        id BIGINT AUTO_INCREMENT PRIMARY KEY,
                        group_id VARCHAR(64) NOT NULL,
                        team_name VARCHAR(64) NOT NULL,
                        player_name VARCHAR(64) NOT NULL,
                        UNIQUE KEY uk_group_team_player (group_id, team_name, player_name),
                        INDEX idx_teams_group (group_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                    """
                )
                await cur.execute(
                    "CREATE TABLE IF NOT EXISTS schema_version (version INT NOT NULL)"
                )
                await cur.execute(
                    """CREATE TABLE IF NOT EXISTS group_home (
                        group_id VARCHAR(64) PRIMARY KEY,
                        home_team VARCHAR(64) NOT NULL,
                        created_at BIGINT NOT NULL
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""
                )
                # v18：战队管理员独立于 QQ 群角色；不从旧群主/群管理自动授予权限。
                await cur.execute(
                    """CREATE TABLE IF NOT EXISTS team_admins (
                        home_team VARCHAR(64) NOT NULL,
                        qq_id VARCHAR(64) NOT NULL,
                        created_at BIGINT NOT NULL,
                        PRIMARY KEY (home_team, qq_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""
                )
                await cur.execute(
                    """CREATE TABLE IF NOT EXISTS users (
                        id BIGINT AUTO_INCREMENT PRIMARY KEY,
                        home_team VARCHAR(64) NOT NULL,
                        name VARCHAR(64) NOT NULL,
                        qq_id VARCHAR(64) DEFAULT '',
                        created_at BIGINT NOT NULL,
                        UNIQUE KEY uk_team_name (home_team, name)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""
                )
                await cur.execute(
                    """CREATE TABLE IF NOT EXISTS player_ids (
                        id BIGINT AUTO_INCREMENT PRIMARY KEY,
                        home_team VARCHAR(64) NOT NULL,
                        player_name VARCHAR(64) NOT NULL,
                        user_id BIGINT NULL,
                        created_at BIGINT NOT NULL,
                        UNIQUE KEY uk_team_player (home_team, player_name),
                        INDEX idx_team_user (home_team, user_id)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""
                )
                # v21：云端站点记录独立存档；不进入 matches/duels 与本地统计。
                await cur.execute(
                    """CREATE TABLE IF NOT EXISTS cloud_battle_reports (
                        cloud_id BIGINT UNSIGNED NOT NULL PRIMARY KEY,
                        team_a VARCHAR(64) NOT NULL DEFAULT '',
                        team_b VARCHAR(64) NOT NULL DEFAULT '',
                        match_time DATE NULL,
                        publish_date DATE NULL,
                        winner_site VARCHAR(64) NOT NULL DEFAULT '',
                        loser_site VARCHAR(64) NOT NULL DEFAULT '',
                        publisher VARCHAR(255) NOT NULL DEFAULT '',
                        query_team VARCHAR(64) NOT NULL DEFAULT '',
                        source_url TEXT NOT NULL,
                        body LONGTEXT NOT NULL,
                        parsed_json LONGTEXT NOT NULL,
                        content_hash CHAR(64) CHARACTER SET ascii NOT NULL,
                        created_at BIGINT NOT NULL,
                        last_seen_at BIGINT NOT NULL,
                        INDEX idx_cloud_match (match_time, cloud_id),
                        INDEX idx_cloud_publish (publish_date, cloud_id),
                        INDEX idx_cloud_team_a (team_a, match_time),
                        INDEX idx_cloud_team_b (team_b, match_time)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""
                )
                # 新增表用 CREATE TABLE IF NOT EXISTS 就够，**不需要 information_schema
                # 探测** —— 探测是给 ALTER 用的（重放时 ADD COLUMN 会报 1060）。建表语句
                # 本身幂等，所以这里跟 group_home / users 一样无条件建。
                await cur.execute(
                    """CREATE TABLE IF NOT EXISTS settlements (
                        id BIGINT AUTO_INCREMENT PRIMARY KEY,
                        home_team VARCHAR(64) NOT NULL,
                        month CHAR(7) NOT NULL,
                        player_name VARCHAR(64) NOT NULL,
                        rank_no INT NOT NULL,
                        total_points DECIMAL(10,2) NOT NULL DEFAULT 0,
                        bonus DECIMAL(8,2) NOT NULL DEFAULT 0,
                        created_at BIGINT NOT NULL,
                        UNIQUE KEY uk_settle (home_team, month, player_name),
                        INDEX idx_settle_team_month (home_team, month)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""
                )
                async def column_exists(table: str, column: str) -> bool:
                    await cur.execute(
                        "SELECT COUNT(*) FROM information_schema.COLUMNS "
                        "WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s AND COLUMN_NAME = %s",
                        (table, column),
                    )
                    return (await cur.fetchone())[0] > 0

                async def ensure_column(table: str, column: str, definition: str):
                    if not await column_exists(table, column):
                        await cur.execute(f"ALTER TABLE {table} ADD COLUMN {column} {definition}")

                # 迁移
                await cur.execute("SELECT COALESCE(MAX(version), 0) FROM schema_version")
                row = await cur.fetchone()
                current = row[0] if row else 0
                if current < 2:
                    # v2：matches 增加 winner 列（记录胜者战队）
                    await ensure_column("matches", "winner", "VARCHAR(64) DEFAULT ''")
                if current < 3:
                    # v3：matches 增加 home_team 列（记录上传方主体战队）
                    await ensure_column("matches", "home_team", "VARCHAR(64) DEFAULT ''")
                if current < 7:
                    # v7：群禁用表（超级管理员控制群级功能开关）
                    await cur.execute(
                        """CREATE TABLE IF NOT EXISTS group_ban (
                            group_id VARCHAR(64) PRIMARY KEY,
                            banned INT NOT NULL,
                            created_at BIGINT NOT NULL
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""
                    )
                if current < 6:
                    # v6：单表存储参赛ID池与绑定（player_ids.user_id 可空，NULL=未绑定）
                    await cur.execute("ALTER TABLE player_ids MODIFY user_id INT NULL")
                    now = int(time.time())
                    await cur.execute(
                        "SELECT COUNT(*) AS c FROM information_schema.tables "
                        "WHERE table_schema = DATABASE() AND table_name = 'team_players'"
                    )
                    has_tp = (await cur.fetchone())[0] > 0
                    if has_tp:
                        # 从旧 team_players 迁移池数据（未绑定），再删表
                        await cur.execute(
                            """INSERT IGNORE INTO player_ids (home_team, player_name, user_id, created_at)
                               SELECT home_team, player_name, NULL, %s FROM team_players""",
                            (now,),
                        )
                        await cur.execute("DROP TABLE team_players")
                    else:
                        # 从已有战报回填参赛ID池（按队伍去重）
                        await cur.execute(
                            """INSERT IGNORE INTO player_ids (home_team, player_name, user_id, created_at)
                               SELECT d.player_a_team, d.player_a, NULL, %s FROM duels d
                               WHERE d.player_a_team != ''
                               UNION
                               SELECT d.player_b_team, d.player_b, NULL, %s FROM duels d
                               WHERE d.player_b_team != ''""",
                            (now, now),
                        )
                if current < 8:
                    # v8：matches 记录原始战报文本（逐字回放导出）；duels 记录对阵顺序
                    await ensure_column("matches", "raw_text", "MEDIUMTEXT")
                    await ensure_column("duels", "seq", "INT NOT NULL DEFAULT 0")
                    # 回填旧数据 seq：按 match 内 id 顺序编号
                    await cur.execute(
                        """UPDATE duels d JOIN (
                               SELECT id, ROW_NUMBER() OVER (PARTITION BY match_id ORDER BY id) rn
                               FROM duels
                           ) x ON d.id = x.id SET d.seq = x.rn"""
                    )
                if current < 9:
                    # v9：duels 记录替补标识（a_sub / b_sub，1=替补）
                    await ensure_column("duels", "a_sub", "TINYINT NOT NULL DEFAULT 0")
                    await ensure_column("duels", "b_sub", "TINYINT NOT NULL DEFAULT 0")
                if current < 10:
                    # v10：自增主键/外键/QQ用户ID/时间戳从 INT 扩容到 BIGINT，
                    # 防止数据量达十位后自增溢出、QQ号溢出、以及 2038 年时间戳溢出。
                    await cur.execute(
                        "SELECT COUNT(*) AS n FROM information_schema.TABLE_CONSTRAINTS "
                        "WHERE constraint_schema = DATABASE() AND table_name = 'duels' "
                        "AND constraint_name = 'fk_duels_match'"
                    )
                    fk_exists = (await cur.fetchone())[0] > 0
                    if fk_exists:
                        # 外键会阻止 match_id 类型变更，先删后加
                        await cur.execute("ALTER TABLE duels DROP FOREIGN KEY fk_duels_match")
                    for sql in (
                        "ALTER TABLE matches MODIFY id BIGINT NOT NULL AUTO_INCREMENT",
                        "ALTER TABLE matches MODIFY created_at BIGINT NOT NULL",
                        "ALTER TABLE duels MODIFY id BIGINT NOT NULL AUTO_INCREMENT",
                        "ALTER TABLE duels MODIFY match_id BIGINT NOT NULL",
                        "ALTER TABLE teams MODIFY id BIGINT NOT NULL AUTO_INCREMENT",
                        "ALTER TABLE users MODIFY id BIGINT NOT NULL AUTO_INCREMENT",
                        "ALTER TABLE users MODIFY created_at BIGINT NOT NULL",
                        "ALTER TABLE player_ids MODIFY id BIGINT NOT NULL AUTO_INCREMENT",
                        "ALTER TABLE player_ids MODIFY user_id BIGINT NULL",
                        "ALTER TABLE player_ids MODIFY created_at BIGINT NOT NULL",
                        "ALTER TABLE group_home MODIFY created_at BIGINT NOT NULL",
                        "ALTER TABLE group_ban MODIFY created_at BIGINT NOT NULL",
                    ):
                        await cur.execute(sql)
                    await cur.execute(
                        "ALTER TABLE duels ADD CONSTRAINT fk_duels_match FOREIGN KEY (match_id) "
                        "REFERENCES matches(id) ON DELETE CASCADE"
                    )
                if current < 11:
                    # v11：群属性表（友谊群/战报群/主群，缺省友谊群）
                    await cur.execute(
                        """CREATE TABLE IF NOT EXISTS group_chat_type (
                            group_id VARCHAR(64) PRIMARY KEY,
                            chat_type VARCHAR(16) NOT NULL
                        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""
                    )
                if current < 12:
                    # v12：duels 记录判罚落败标记（a_ruled / b_ruled，1=判罚落败）
                    await ensure_column("duels", "a_ruled", "TINYINT NOT NULL DEFAULT 0")
                    await ensure_column("duels", "b_ruled", "TINYINT NOT NULL DEFAULT 0")
                if current < 13:
                    # v13：判罚标记合并为单字段 ruled（1=本场对局被规则）；判罚方比分更低即败方
                    await ensure_column("duels", "ruled", "TINYINT NOT NULL DEFAULT 0")
                    for legacy_column in ("a_ruled", "b_ruled"):
                        if await column_exists("duels", legacy_column):
                            await cur.execute(f"UPDATE duels SET ruled = 1 WHERE {legacy_column} = 1")
                            await cur.execute(f"ALTER TABLE duels DROP COLUMN {legacy_column}")
                if current < 14:
                    # v14：回填替补标记——某选手同场首轮（round_no==1）未出场、却在后续轮次
                    # 出场，即视为替补（a_sub/b_sub=1）。领域规则：替补替换首轮选手、不扩容
                    # 总出战人数。首轮名单只认 player_a 侧（player_b 对称）；含 0:0 占位。
                    # 注意：MySQL 不允许 UPDATE 目标表在子查询里直接 SELECT 同一张表（错误
                    # 1093），须把子查询包成派生表 (r1) 强制物化快照。
                    await cur.execute(
                        """UPDATE duels d
                           SET d.a_sub = 1
                           WHERE d.round_no > 1 AND d.a_sub = 0
                             AND NOT EXISTS (
                                 SELECT 1 FROM (
                                     SELECT match_id, player_a FROM duels WHERE round_no = 1
                                 ) r1
                                 WHERE r1.match_id = d.match_id
                                   AND r1.player_a = d.player_a
                             )"""
                    )
                    await cur.execute(
                        """UPDATE duels d
                           SET d.b_sub = 1
                           WHERE d.round_no > 1 AND d.b_sub = 0
                             AND NOT EXISTS (
                                 SELECT 1 FROM (
                                     SELECT match_id, player_b FROM duels WHERE round_no = 1
                                 ) r1
                                 WHERE r1.match_id = d.match_id
                                   AND r1.player_b = d.player_b
                             )"""
                    )
                if current < 15:
                    # v15：matches 增加内容指纹列，用于拒绝「完全相同的战报」重复入库
                    # （同一份战报提交两次会让统计翻倍）。指纹由 report_fingerprint()
                    # 计算，不含 group_id/提交人/地点 —— 同一战队的另一个群再提交一次
                    # 也算重复。历史行留 NULL：MySQL 唯一索引不对 NULL 去重，所以既
                    # 不需要回填，也不会因存量重复数据而迁移失败。
                    #
                    # ⚠️ 必须先探测再执行：_init_schema 没有外层 try/except，而版本号是
                    # 所有分支跑完后才写的。若「ALTER 成功、写版本号前进程被杀」导致本
                    # 分支重放，ADD COLUMN 会报 1060、ADD UNIQUE 会报 1061 → initialize()
                    # 抛错 → db_ready=False → 整个插件永久起不来。
                    await cur.execute(
                        "SELECT COUNT(*) AS n FROM information_schema.COLUMNS "
                        "WHERE table_schema = DATABASE() AND table_name = 'matches' "
                        "AND column_name = 'fingerprint'"
                    )
                    if (await cur.fetchone())[0] == 0:
                        await cur.execute(
                            "ALTER TABLE matches ADD COLUMN fingerprint CHAR(64) NULL DEFAULT NULL"
                        )
                    await cur.execute(
                        "SELECT COUNT(*) AS n FROM information_schema.STATISTICS "
                        "WHERE table_schema = DATABASE() AND table_name = 'matches' "
                        "AND index_name = 'uk_matches_fingerprint'"
                    )
                    if (await cur.fetchone())[0] == 0:
                        await cur.execute(
                            "ALTER TABLE matches "
                            "ADD UNIQUE KEY uk_matches_fingerprint (fingerprint)"
                        )
                if current < 16:
                    # v16：踢馆战报（matches.kind='raid'）+ 馆主标记（duels.owner）。
                    # 复用 matches/duels 而不是新开一对表：写入/删除/撤销/指纹去重/
                    # 导出/参赛ID池全部现成。代价是**所有友谊赛聚合必须显式加
                    # `AND m.kind = 'friendly'`** —— 否则踢馆对局会混进友谊胜负与
                    # 友谊次数。新增查询时务必照做（§7.1 有传导行）。
                    #
                    # owner 只认**防守方（右侧）**，与 ruled 的单字段风格一致。
                    # 同样先探测再 ALTER：_init_schema 没有外层 try/except，重放时
                    # ADD COLUMN 报 1060 会让整个插件起不来（见 v15 注释）。
                    await cur.execute(
                        "SELECT COUNT(*) AS n FROM information_schema.COLUMNS "
                        "WHERE table_schema = DATABASE() AND table_name = 'matches' "
                        "AND column_name = 'kind'"
                    )
                    if (await cur.fetchone())[0] == 0:
                        await cur.execute(
                            "ALTER TABLE matches ADD COLUMN kind VARCHAR(16) "
                            "NOT NULL DEFAULT 'friendly'"
                        )
                    await cur.execute(
                        "SELECT COUNT(*) AS n FROM information_schema.COLUMNS "
                        "WHERE table_schema = DATABASE() AND table_name = 'duels' "
                        "AND column_name = 'owner'"
                    )
                    if (await cur.fetchone())[0] == 0:
                        await cur.execute(
                            "ALTER TABLE duels ADD COLUMN owner TINYINT NOT NULL DEFAULT 0"
                        )
                # v17：月度结算（settlements 表）。表本身在上面已经无条件建好，这里
                # 没有需要迁移的存量数据 —— 所以**没有 current < 17 的分支**，靠末尾
                # 那句统一的「写版本行」推进。v18 的 team_admins 同样使用幂等建表。
                if current < 19:
                    await ensure_column("matches", "export_sent", "TINYINT NOT NULL DEFAULT 0")
                # 旧INT用户表须先完成v10扩容，再建立BIGINT身份外键；此处仍幂等。
                # v20：QQ 与官方 OpenID 同一身份的附加关联，保留 users.qq_id。
                await cur.execute(
                    """CREATE TABLE IF NOT EXISTS official_user_accounts (
                        appid VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
                        openid VARCHAR(128) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
                        user_id BIGINT NOT NULL,
                        qq_id VARCHAR(64) NOT NULL,
                        created_at BIGINT NOT NULL,
                        PRIMARY KEY (appid, openid),
                        UNIQUE KEY uk_official_qq (appid, qq_id),
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""
                )
                await cur.execute(
                    """CREATE TABLE IF NOT EXISTS official_link_requests (
                        token_hash CHAR(64) CHARACTER SET ascii COLLATE ascii_bin PRIMARY KEY,
                        home_team VARCHAR(64) NOT NULL,
                        appid VARCHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
                        openid VARCHAR(128) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
                        user_id BIGINT NOT NULL,
                        owner_qq VARCHAR(64) NOT NULL,
                        expires_at BIGINT NOT NULL,
                        created_at BIGINT NOT NULL,
                        INDEX idx_official_request (appid, openid),
                        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4"""
                )
                if current < SCHEMA_VERSION:
                    await cur.execute("INSERT INTO schema_version (version) VALUES (%s)", (SCHEMA_VERSION,))

    async def close(self) -> None:
        if self.pool:
            self.pool.close()
            await self.pool.wait_closed()
            self.pool = None

    # ---------- 基础查询封装 ----------

    async def _query(self, sql: str, params: tuple = ()) -> list[dict]:
        assert self.pool is not None
        async with self.pool.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cur:
                await cur.execute(sql, params)
                rows = await cur.fetchall()
        # aiomysql 的 DictCursor.fetchall() 在**没有行**时返回空 tuple、有行时返回
        # list —— 空结果集的上游是 `tuple(self._rows)`，非空走的是 `list`。调用方
        # 会就地改这些行（`sort_ranking` 排序、`get_home_team_vs_opponents` 追加
        # 只踢过馆的对手），拿到 tuple 就会 AttributeError 崩在"查无记录"这条路上。
        # 在这里统一成 list，兑现 `-> list[dict]` 的签名。
        return list(rows)

    async def _execute(self, sql: str, params: tuple = ()) -> int:
        """执行单条写语句，返回受影响行数。"""
        assert self.pool is not None
        async with self.pool.acquire() as conn:
            async with conn.cursor() as cur:
                await cur.execute(sql, params)
                return cur.rowcount

    # ---------- 战报写入 / 删除 ----------

    async def insert_report(self, report, winner: str = "", home_team: str = "", raw_text: str = "") -> int:
        """插入一份战报（match + duels），返回 match_id。winner 为胜者，home_team 为上传方主体战队，raw_text 为原始战报文本（逐字回放导出用）。

        内容指纹与既有战报完全相同时抛 `DuplicateReportError`（带已存在的
        match_id），且不写入任何数据 —— 同一份战报提交两次会让统计翻倍。
        """
        assert self.pool is not None
        fingerprint = report_fingerprint(report, home_team)
        async with self.pool.acquire() as conn:
            await conn.begin()
            try:
                async with conn.cursor() as cur:
                    # 预检：用本事务内的 cursor，而不是 self._query()（后者会另借一条
                    # 连接、脱离本事务）。这只是为了拿到友好提示所需的旧 id；并发场景
                    # 由下面的唯一索引兜住，所以此处不需要加锁。
                    await cur.execute(
                        "SELECT id FROM matches WHERE fingerprint = %s LIMIT 1",
                        (fingerprint,),
                    )
                    row = await cur.fetchone()
                    if row:
                        raise DuplicateReportError(int(row[0]))
                    await cur.execute(
                        """INSERT INTO matches
                           (group_id, team_a, team_b, match_time, rule, location,
                            submitted_by, submitted_name, created_at, winner, home_team,
                            raw_text, fingerprint, kind)
                           VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                        (
                            report.group_id,
                            report.team_a,
                            report.team_b,
                            report.match_time,
                            report.rule,
                            report.location,
                            report.submitted_by,
                            report.submitted_name,
                            int(report.created_at) if report.created_at else 0,
                            winner or "",
                            home_team or "",
                            raw_text or "",
                            fingerprint,
                            getattr(report, "kind", KIND_FRIENDLY) or KIND_FRIENDLY,
                        ),
                    )
                    match_id = cur.lastrowid
                    now = int(time.time())
                    for seq, duel in enumerate(report.duels):
                        await cur.execute(
                            """INSERT INTO duels
                               (match_id, round_no, player_a, score_a, player_b, score_b,
                                player_a_team, player_b_team, result, seq, a_sub, b_sub, ruled,
                                owner)
                               VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)""",
                            (
                                match_id,
                                duel.round_no,
                                duel.player_a,
                                duel.score_a,
                                duel.player_b,
                                duel.score_b,
                                report.team_a,
                                report.team_b,
                                "A" if duel.score_a > duel.score_b
                                else ("B" if duel.score_a < duel.score_b else "DRAW"),
                                seq,
                                1 if getattr(duel, "a_sub", False) else 0,
                                1 if getattr(duel, "b_sub", False) else 0,
                                1 if getattr(duel, "ruled", False) else 0,
                                1 if getattr(duel, "owner", False) else 0,
                            ),
                        )
                        # 参赛ID按队伍去重入库（发送战报时处理，保留已有绑定）。
                        # 踢馆报里防守方是 `规则` 的空位行不进 ID 池：那不是一个选手，
                        # 建进去会让战队花名册里多出一个叫「规则」的假人。
                        for team, name in (
                            (report.team_a, duel.player_a),
                            (report.team_b, duel.player_b),
                        ):
                            if name == RAID_PLACEHOLDER:
                                continue
                            await cur.execute(
                                """INSERT INTO player_ids (home_team, player_name, user_id, created_at)
                                   VALUES (%s, %s, NULL, %s) AS new
                                   ON DUPLICATE KEY UPDATE player_name = new.player_name""",
                                (team, name, now),
                            )
                await conn.commit()
                return match_id
            except DuplicateReportError:
                await conn.rollback()
                raise
            except IntegrityError as e:
                # 并发兜底：两个请求同时通过上面的预检时，唯一索引会拦住后到的那个。
                # InnoDB 会让后到的插入等待前一个事务结束，所以拿到 1062 时对方
                # 一定已提交。回滚已结束旧快照，直接复用本连接回查，避免重复请求
                # 占满连接池后又各自借第二条连接造成死锁。
                await conn.rollback()
                if e.args and e.args[0] == _DUP_ENTRY and "uk_matches_fingerprint" in str(e):
                    async with conn.cursor() as cur:
                        await cur.execute("SELECT id FROM matches WHERE fingerprint = %s LIMIT 1", (fingerprint,))
                        row = await cur.fetchone()
                    raise DuplicateReportError(int(row[0]) if row else None) from None
                raise
            except Exception:
                await conn.rollback()
                raise

    async def delete_match(self, group_id: str, match_id: int) -> bool:
        """删除指定群、指定 ID 的战报及其关联对局（校验群归属），返回是否删除成功。

        先按群归属校验后删除 duels 关联数据，再删除 matches 本身。若外键
        ON DELETE CASCADE 未生效（旧表结构），duels 不会残留。
        """
        assert self.pool is not None
        async with self.pool.acquire() as conn:
            await conn.begin()
            try:
                async with conn.cursor() as cur:
                    await cur.execute(
                        """DELETE FROM duels
                           WHERE match_id IN (SELECT id FROM matches
                                              WHERE id = %s AND group_id = %s)""",
                        (match_id, group_id),
                    )
                    await cur.execute(
                        "DELETE FROM matches WHERE id = %s AND group_id = %s",
                        (match_id, group_id),
                    )
                    deleted = cur.rowcount
                await conn.commit()
            except Exception:
                await conn.rollback()
                raise
        return deleted > 0

    async def get_last_match_by_submitter(self, group_id: str, submitter: str) -> int | None:
        """查询某提交者在该群最近一条战报 ID。"""
        rows = await self._query(
            """SELECT id FROM matches WHERE group_id = %s AND submitted_by = %s
               ORDER BY id DESC LIMIT 1""",
            (group_id, submitter),
        )
        return rows[0]["id"] if rows else None

    # ---------- 战队名单 ----------

    async def replace_teams(self, group_id: str, teams: list[tuple[str, list[str]]]) -> None:
        """覆盖写入某群的战队名单（先清空再写入）。"""
        assert self.pool is not None
        async with self.pool.acquire() as conn:
            await conn.begin()
            try:
                async with conn.cursor() as cur:
                    await cur.execute("DELETE FROM teams WHERE group_id = %s", (group_id,))
                    for team_name, players in teams:
                        for player in players:
                            await cur.execute(
                                """INSERT IGNORE INTO teams (group_id, team_name, player_name)
                                   VALUES (%s, %s, %s)""",
                                (group_id, team_name, player),
                            )
                await conn.commit()
            except Exception:
                await conn.rollback()
                raise

    # ---------- 群主体绑定 ----------

    async def set_team_admins(self, home_team: str, qq_ids: list[str], *, expected: list[str] | None = None) -> None:
        """覆盖本队管理员名单；使用同队身份锁保证并发设置的一致性。"""
        async with self._identity_cursor(home_team) as cur:
            if expected is not None:
                await cur.execute('SELECT qq_id FROM team_admins WHERE home_team=%s ORDER BY qq_id', (home_team,))
                if sorted(row['qq_id'] for row in await cur.fetchall()) != sorted(set(expected)):
                    raise ValueError('管理员名单已变化，请刷新后重试。')
            await cur.execute("DELETE FROM team_admins WHERE home_team = %s", (home_team,))
            for qq in dict.fromkeys(qq_ids):
                await cur.execute(
                    "INSERT INTO team_admins (home_team, qq_id, created_at) VALUES (%s, %s, %s)",
                    (home_team, qq, int(time.time())),
                )

    async def remove_team_admin(self, home_team: str, qq_id: str) -> int:
        async with self._identity_cursor(home_team) as cur:
            await cur.execute("DELETE FROM team_admins WHERE home_team = %s AND qq_id = %s", (home_team, qq_id))
            return cur.rowcount

    async def get_team_admins(self, home_team: str) -> list[str]:
        rows = await self._query("SELECT qq_id FROM team_admins WHERE home_team = %s ORDER BY qq_id", (home_team,))
        return [row["qq_id"] for row in rows]

    async def get_admin_teams(self, qq_id: str) -> list[str]:
        rows = await self._query('SELECT home_team FROM team_admins WHERE qq_id=%s ORDER BY home_team', (qq_id,))
        return [row['home_team'] for row in rows]

    async def get_team_admin_qqs(self) -> list[str]:
        rows = await self._query('SELECT DISTINCT qq_id FROM team_admins ORDER BY qq_id', ())
        return [row['qq_id'] for row in rows]

    async def is_team_admin(self, home_team: str, qq_id: str) -> bool:
        return bool(await self._query(
            "SELECT 1 FROM team_admins WHERE home_team = %s AND qq_id = %s LIMIT 1", (home_team, qq_id)
        ))

    async def set_group_home(self, group_id: str, home_team: str) -> None:
        """绑定群的主体战队（覆盖写入）。"""
        await self._execute(
            """INSERT INTO group_home (group_id, home_team, created_at)
               VALUES (%s, %s, %s) AS new
               ON DUPLICATE KEY UPDATE home_team = new.home_team""",
            (group_id, home_team, int(time.time())),
        )

    async def get_group_home(self, group_id: str) -> str | None:
        """获取群绑定的主体战队；未绑定返回 None。"""
        rows = await self._query(
            "SELECT home_team FROM group_home WHERE group_id = %s",
            (group_id,),
        )
        return rows[0]["home_team"] if rows else None

    async def set_group_chat_type(self, group_id: str, chat_type: str) -> None:
        """设置群属性，只接受友谊群、战报群或主群。"""
        chat_type = normalize_chat_type(chat_type)
        if chat_type is None:
            raise ValueError("群属性应为友谊群、战报群或主群")
        await self._execute(
            """INSERT INTO group_chat_type (group_id, chat_type)
               VALUES (%s, %s) AS new
               ON DUPLICATE KEY UPDATE chat_type = new.chat_type""",
            (group_id, chat_type),
        )

    async def get_group_chat_type_setting(self, group_id: str) -> str | None:
        """读取明确设置的属性；没有设置或旧值无效时返回 None。"""
        rows = await self._query(
            "SELECT chat_type FROM group_chat_type WHERE group_id = %s",
            (group_id,),
        )
        return normalize_chat_type(rows[0]["chat_type"]) if rows else None

    async def get_group_chat_type(self, group_id: str) -> str:
        """获取实际用途；未明确设置时默认友谊群，不自动写入设置。"""
        return await self.get_group_chat_type_setting(group_id) or FRIENDLY_GROUP

    async def backfill_group_home(self, group_id: str, home_team: str) -> None:
        """把该群已有战报的 home_team 回填为当前主体。"""
        await self._execute(
            "UPDATE matches SET home_team = %s WHERE group_id = %s AND home_team = ''",
            (home_team, group_id),
        )

    # ---------- 群禁用 ----------

    async def set_group_ban(self, group_id: str, banned: bool) -> None:
        """设置群禁用状态（超级管理员控制）。"""
        await self._execute(
            """INSERT INTO group_ban (group_id, banned, created_at)
               VALUES (%s, %s, %s) AS new
               ON DUPLICATE KEY UPDATE banned = new.banned""",
            (group_id, 1 if banned else 0, int(time.time())),
        )

    async def get_group_ban(self, group_id: str) -> bool:
        """群是否被禁用。"""
        rows = await self._query(
            "SELECT banned FROM group_ban WHERE group_id = %s",
            (group_id,),
        )
        return bool(rows and rows[0]["banned"])

    async def get_all_teams(self) -> list[str]:
        """全部战队（来自绑定、参赛ID、战报对阵）。"""
        rows = await self._query(
            """SELECT DISTINCT t.team FROM (
                   SELECT home_team AS team FROM group_home WHERE home_team != ''
                   UNION SELECT home_team FROM player_ids WHERE home_team != ''
                   UNION SELECT team_a FROM matches WHERE team_a != ''
                   UNION SELECT team_b FROM matches WHERE team_b != ''
               ) t ORDER BY t.team"""
        )
        return [r["team"] for r in rows]

    async def get_all_groups(self, home_team: str | None = None) -> list[dict]:
        """全部群及其绑定战队与禁用状态；可按战队过滤。"""
        rows = await self._query(
            """SELECT t.group_id, t.home_team, t.banned FROM (
                   SELECT g.group_id, g.home_team, COALESCE(b.banned, 0) AS banned
                   FROM group_home g LEFT JOIN group_ban b ON g.group_id = b.group_id
                   UNION
                   SELECT b.group_id, '', b.banned FROM group_ban b
                   LEFT JOIN group_home g ON b.group_id = g.group_id
                   WHERE g.group_id IS NULL
               ) t ORDER BY t.group_id"""
        )
        if home_team:
            rows = [r for r in rows if r["home_team"] == home_team]
        return rows

    # ---------- 用户与参赛ID ----------

    async def get_webui_teams(self, keyword: str, offset: int, limit: int) -> dict:
        source = """(SELECT home_team AS team FROM group_home UNION SELECT home_team FROM users
                     UNION SELECT home_team FROM player_ids UNION SELECT home_team FROM team_admins
                     UNION SELECT home_team FROM matches UNION SELECT team_a FROM matches
                     UNION SELECT team_b FROM matches) t WHERE t.team<>'' AND LOCATE(%s,t.team)>0"""
        total = (await self._query('SELECT COUNT(*) AS n FROM '+source, (keyword,)))[0]['n']
        rows = await self._query('SELECT t.team FROM '+source+' ORDER BY t.team LIMIT %s OFFSET %s',
                                 (keyword,limit,offset))
        if not rows:return dict(total=total,records=[])
        names=[r['team'] for r in rows];slots=','.join(['%s']*len(names))
        admins=await self._query(f'SELECT home_team,qq_id FROM team_admins WHERE home_team IN ({slots}) ORDER BY qq_id',tuple(names))
        groups=await self._query(f"""SELECT g.home_team,g.group_id,COALESCE(b.banned,0) AS banned,c.chat_type
            FROM group_home g LEFT JOIN group_ban b ON b.group_id=g.group_id
            LEFT JOIN group_chat_type c ON c.group_id=g.group_id
            WHERE g.home_team IN ({slots}) ORDER BY g.group_id""",tuple(names))
        members=await self._query(f'SELECT home_team,COUNT(*) AS n FROM users WHERE home_team IN ({slots}) GROUP BY home_team',tuple(names))
        players=await self._query(f'SELECT home_team,COUNT(*) AS n FROM player_ids WHERE home_team IN ({slots}) GROUP BY home_team',tuple(names))
        def same(a,b):return a.casefold()==b.casefold()
        for row in rows:
            team=row['team']
            row['admins']=[a['qq_id'] for a in admins if same(a['home_team'],team)]
            row['groups']=[dict(group_id=g['group_id'],banned=bool(g['banned']),chat_type=g['chat_type']) for g in groups if same(g['home_team'],team)]
            row['member_count']=sum(r['n'] for r in members if same(r['home_team'],team))
            row['player_count']=sum(r['n'] for r in players if same(r['home_team'],team))
        return dict(total=total,records=rows)

    async def get_webui_members(self, home_team: str, keyword: str, offset: int, limit: int) -> dict:
        where="""u.home_team=%s AND (LOCATE(%s,u.name)>0 OR LOCATE(%s,u.qq_id)>0 OR EXISTS
            (SELECT 1 FROM player_ids p WHERE p.home_team=u.home_team AND p.user_id=u.id AND LOCATE(%s,p.player_name)>0))"""
        params=(home_team,keyword,keyword,keyword)
        total=(await self._query('SELECT COUNT(*) AS n FROM users u WHERE '+where,params))[0]['n']
        rows=await self._query("SELECT u.id,u.name,COALESCE(u.qq_id,'') AS qq_id,u.created_at FROM users u WHERE "+where+
                              ' ORDER BY u.id LIMIT %s OFFSET %s',(*params,limit,offset))
        if rows:
            slots=','.join(['%s']*len(rows))
            players=await self._query(f'SELECT user_id,player_name FROM player_ids WHERE home_team=%s AND user_id IN ({slots}) ORDER BY id',
                                     (home_team,*(r['id'] for r in rows)))
            for row in rows:
                row['players']=[p['player_name'] for p in players if p['user_id']==row['id']]
                row['id']=str(row['id'])
        return dict(total=total,records=rows)

    async def get_webui_players(self, home_team: str, keyword: str, offset: int, limit: int, *, unbound: bool = False) -> dict:
        source="""FROM player_ids p LEFT JOIN users u ON u.id=p.user_id AND u.home_team=p.home_team
            WHERE p.home_team=%s AND (LOCATE(%s,p.player_name)>0 OR LOCATE(%s,u.name)>0 OR LOCATE(%s,u.qq_id)>0)"""
        if unbound:source+=' AND p.user_id IS NULL'
        params=(home_team,keyword,keyword,keyword)
        total=(await self._query('SELECT COUNT(*) AS n '+source,params))[0]['n']
        rows=await self._query('SELECT p.player_name,p.user_id,u.name AS user_name,u.qq_id '+source+
                              ' ORDER BY p.id LIMIT %s OFFSET %s',(*params,limit,offset))
        for row in rows:row['user_id']=str(row['user_id']) if row['user_id'] is not None else None
        return dict(total=total,records=rows)

    async def save_webui_member(self, home_team: str, name: str, qq_id: str, *, user_id: int | None = None, expected: dict | None = None) -> str:
        """Explicit admin edit; ownership checks, official unlink and role update commit together."""
        async with self._identity_cursor(home_team) as cur:
            old=None
            if user_id is not None:
                await cur.execute("SELECT name,COALESCE(qq_id,'') AS qq_id FROM users WHERE home_team=%s AND id=%s FOR UPDATE",(home_team,user_id))
                old=await cur.fetchone()
                if old is None:raise ValueError('找不到该战队的队员。')
                if dict(old)!=expected:raise ValueError('队员资料已变化，请刷新后重试。')
            await cur.execute('SELECT id FROM users WHERE home_team=%s AND (name=%s OR (%s<>\'\' AND qq_id=%s)) AND id<>%s',
                              (home_team,name,qq_id,qq_id,user_id or 0))
            if await cur.fetchone():raise ValueError('该战队已有同名角色或该QQ已绑定其他角色。')
            if user_id is None:
                await cur.execute('INSERT INTO users (home_team,name,qq_id,created_at) VALUES (%s,%s,%s,%s)',
                                  (home_team,name,qq_id,int(time.time())))
                user_id=cur.lastrowid
            else:
                if old['qq_id']!=qq_id:
                    await cur.execute('DELETE FROM official_link_requests WHERE user_id=%s',(user_id,))
                    await cur.execute('DELETE FROM official_user_accounts WHERE user_id=%s',(user_id,))
                await cur.execute('UPDATE users SET name=%s,qq_id=%s WHERE home_team=%s AND id=%s',
                                  (name,qq_id,home_team,user_id))
            return str(user_id)

    async def set_webui_player_owner(self, home_team: str, player: str, user_id: int | None, *, expected_owner: int | None) -> None:
        """Only existing IDs; compare the displayed owner before moving or unbinding."""
        async with self._identity_cursor(home_team) as cur:
            await cur.execute('SELECT id,user_id FROM player_ids WHERE home_team=%s AND player_name=%s FOR UPDATE',(home_team,player))
            row=await cur.fetchone()
            if row is None:raise ValueError('该战队没有这个参赛ID。')
            if row['user_id']!=expected_owner:raise ValueError('参赛ID归属已变化，请刷新后重试。')
            if user_id is not None:
                await cur.execute('SELECT id FROM users WHERE home_team=%s AND id=%s',(home_team,user_id))
                if not await cur.fetchone():raise ValueError('目标角色不属于该战队。')
            await cur.execute('UPDATE player_ids SET user_id=%s WHERE home_team=%s AND id=%s',(user_id,home_team,row['id']))

    @asynccontextmanager
    async def _identity_cursor(self, home_team: str):
        """同战队身份操作串行化（含多进程），并在一笔事务里完成校验和写入。"""
        assert self.pool is not None
        lock_key = hashlib.sha256(
            f"battle-report:identity:{self.db}:{home_team.casefold()}".encode()
        ).hexdigest()
        async with self.pool.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cur:
                await cur.execute("SELECT GET_LOCK(%s, 10) AS acquired", (lock_key,))
                if (await cur.fetchone())["acquired"] != 1:
                    raise RuntimeError("身份操作繁忙，请稍后重试")
                try:
                    await conn.begin()
                    try:
                        yield cur
                        await conn.commit()
                    except BaseException:
                        await conn.rollback()
                        raise
                finally:
                    try:
                        await cur.execute("SELECT RELEASE_LOCK(%s)", (lock_key,))
                    except BaseException:
                        # 命名锁属于连接，释放失败的连接不能放回连接池。
                        conn.close()
                        raise

    async def _find_or_create_user(self, cur, home_team: str, name: str, qq_id: str) -> int:
        if qq_id:
            await cur.execute(
                "SELECT id FROM users WHERE home_team = %s AND qq_id = %s",
                (home_team, qq_id),
            )
            row = await cur.fetchone()
            if row:
                return row["id"]
        await cur.execute(
            "SELECT id, qq_id FROM users WHERE home_team = %s AND name = %s",
            (home_team, name),
        )
        row = await cur.fetchone()
        if row:
            if qq_id and row["qq_id"] and str(row["qq_id"]) != str(qq_id):
                raise ValueError("该角色已被其他 QQ 认领")
            if qq_id and not row["qq_id"]:
                await cur.execute("UPDATE users SET qq_id = %s WHERE id = %s", (qq_id, row["id"]))
            return row["id"]
        await cur.execute(
            "INSERT INTO users (home_team, name, qq_id, created_at) VALUES (%s, %s, %s, %s)",
            (home_team, name, qq_id, int(time.time())),
        )
        return cur.lastrowid

    async def find_or_create_user(self, home_team: str, name: str, qq_id: str = "") -> int:
        """优先复用该 QQ 的角色；同名角色不得绕过归属校验。"""
        async with self._identity_cursor(home_team) as cur:
            return await self._find_or_create_user(cur, home_team, name, qq_id)

    async def bind_player_to_self(self, home_team: str, player: str, qq_id: str) -> tuple[str, dict | None]:
        """普通成员绑定入口；精确查 ID，认领/建角色/绑定在同一事务内。"""
        async with self._identity_cursor(home_team) as cur:
            await cur.execute(
                "SELECT user_id FROM player_ids WHERE home_team = %s AND player_name = %s FOR UPDATE",
                (home_team, player),
            )
            binding = await cur.fetchone()
            if binding is None:
                return "not_found", None
            await cur.execute(
                "SELECT id, name, qq_id FROM users WHERE home_team = %s AND qq_id = %s",
                (home_team, qq_id),
            )
            mine = await cur.fetchone()
            if binding["user_id"]:
                await cur.execute(
                    "SELECT id, name, qq_id FROM users WHERE home_team = %s AND id = %s",
                    (home_team, binding["user_id"]),
                )
                owner = await cur.fetchone()
                if owner is None:
                    raise ValueError("参赛ID指向不存在的角色，请管理员修复")
                if mine and mine["id"] != owner["id"]:
                    return "bound_else", owner
                if owner["qq_id"] and str(owner["qq_id"]) != str(qq_id):
                    return "claimed_else", owner
                await cur.execute("UPDATE users SET qq_id = %s WHERE id = %s", (qq_id, owner["id"]))
                owner["qq_id"] = qq_id
                return "ok", owner
            try:
                uid = await self._find_or_create_user(cur, home_team, player, qq_id)
            except ValueError:
                return "claimed_else", None
            await cur.execute(
                "UPDATE player_ids SET user_id = %s WHERE home_team = %s AND player_name = %s",
                (uid, home_team, player),
            )
            await cur.execute("SELECT id, name, qq_id FROM users WHERE id = %s", (uid,))
            return "ok", await cur.fetchone()

    async def get_user_by_qq(self, home_team: str, qq_id: str) -> dict | None:
        """按 战队+QQ 查找用户。"""
        rows = await self._query(
            "SELECT id, name, qq_id FROM users WHERE home_team = %s AND qq_id = %s",
            (home_team, qq_id),
        )
        return rows[0] if rows else None

    async def get_official_identity(self, appid: str, openid: str) -> dict | None:
        """通过已验证的 OpenID 取得原 QQ 身份；原角色归属变化时立即失效。"""
        rows = await self._query(
            """SELECT a.user_id, a.qq_id, u.name, u.home_team
               FROM official_user_accounts a JOIN users u ON u.id = a.user_id AND u.qq_id = a.qq_id
               WHERE a.appid = %s AND a.openid = %s""", (appid, openid))
        return rows[0] if rows else None

    async def find_official_link_home(self, query: str) -> str:
        """未设置官方群战队时，仅为身份验证定位唯一原 QQ，不替群绑定战队。"""
        rows = await self._query(
            """SELECT u.home_team, u.qq_id FROM player_ids p JOIN users u ON u.id = p.user_id
               WHERE p.home_team = u.home_team AND p.player_name = %s ORDER BY u.id""", (query,))
        if not rows:
            rows = await self._query("SELECT home_team, qq_id FROM users WHERE name = %s ORDER BY id", (query,))
        owners = {str(row['qq_id']) for row in rows if row['qq_id']}
        if len(owners) != 1 or any(not row['qq_id'] for row in rows):
            raise ValueError("角色不存在或属于多个原账号喵，请先联系管理员设置本群战队。")
        return rows[0]['home_team']

    async def request_official_link(self, home_team: str, appid: str, openid: str, query: str) -> dict:
        """请求关联现有角色，不写 QQ/OpenID 映射；确认码只存哈希，10 分钟有效。"""
        if not appid or not openid or len(appid) > 64 or len(openid) > 128:
            raise ValueError("官方账号标识无效喵。")
        code = secrets.token_hex(8).upper()
        now = int(time.time())
        async with self._identity_cursor(home_team) as cur:
            await cur.execute(
                """SELECT u.id, u.name, u.qq_id FROM player_ids p JOIN users u ON p.user_id = u.id
                   WHERE p.home_team = %s AND u.home_team = %s AND p.player_name = %s""",
                (home_team, home_team, query))
            user = await cur.fetchone()
            if not user:
                await cur.execute("SELECT id, name, qq_id FROM users WHERE home_team = %s AND name = %s",
                                  (home_team, query))
                user = await cur.fetchone()
            if not user:
                raise ValueError("查不到已归属的角色喵，请先在原机器人绑定参赛ID。")
            qq = str(user['qq_id'] or '')
            if not re.fullmatch(r'[1-9][0-9]{4,11}', qq):
                raise ValueError("该角色还没有原 QQ 身份喵，请先在原机器人完成绑定。")
            await cur.execute(
                "SELECT user_id, qq_id, openid FROM official_user_accounts WHERE appid = %s AND openid = %s",
                (appid, openid))
            mine = await cur.fetchone()
            if mine:
                await cur.execute("SELECT qq_id FROM users WHERE id = %s", (mine['user_id'],))
                original = await cur.fetchone()
                if not original or str(original['qq_id']) != qq or str(mine['qq_id']) != qq:
                    raise ValueError("当前官方账号已关联其他账号喵，请先由原 QQ 解除关联。")
                return dict(linked=True, user_id=user['id'], name=user['name'], qq_id=qq)
            await cur.execute("SELECT openid FROM official_user_accounts WHERE appid = %s AND qq_id = %s", (appid, qq))
            if await cur.fetchone():
                raise ValueError("原账号已经关联另一个官方账号喵，请先由原 QQ 解除关联。")
            await cur.execute("DELETE FROM official_link_requests WHERE appid = %s AND openid = %s", (appid, openid))
            await cur.execute("DELETE FROM official_link_requests WHERE home_team = %s AND expires_at <= %s", (home_team, now))
            await cur.execute(
                """INSERT INTO official_link_requests
                   (token_hash, home_team, appid, openid, user_id, owner_qq, expires_at, created_at)
                   VALUES (%s, %s, %s, %s, %s, %s, %s, %s)""",
                (hashlib.sha256(code.encode()).hexdigest(), home_team, appid, openid, user['id'], qq, now + 600, now))
            return dict(linked=False, code=code, name=user['name'])

    async def confirm_official_link(self, code: str, qq: str) -> str:
        """仅请求角色的原 QQ 可确认；检查和消费确认码与身份写入同一事务。"""
        digest = hashlib.sha256(code.upper().encode()).hexdigest()
        rows = await self._query("SELECT home_team FROM official_link_requests WHERE token_hash = %s", (digest,))
        if not rows:
            return 'invalid'
        home = rows[0]['home_team']
        async with self._identity_cursor(home) as cur:
            await cur.execute("SELECT * FROM official_link_requests WHERE token_hash = %s FOR UPDATE", (digest,))
            request = await cur.fetchone()
            if not request:
                return 'invalid'
            if request['expires_at'] <= int(time.time()):
                await cur.execute("DELETE FROM official_link_requests WHERE token_hash = %s", (digest,))
                return 'invalid'
            await cur.execute("SELECT id, qq_id FROM users WHERE home_team = %s AND id = %s FOR UPDATE",
                              (home, request['user_id']))
            user = await cur.fetchone()
            if not user or str(user['qq_id']) != request['owner_qq'] or request['owner_qq'] != str(qq):
                return 'denied'
            await cur.execute(
                """SELECT openid, qq_id FROM official_user_accounts
                   WHERE appid = %s AND (openid = %s OR qq_id = %s) FOR UPDATE""",
                (request['appid'], request['openid'], qq))
            existing = await cur.fetchall()
            if existing and any(e['openid'] != request['openid'] or str(e['qq_id']) != str(qq) for e in existing):
                return 'conflict'
            if not existing:
                await cur.execute(
                    """INSERT INTO official_user_accounts (appid, openid, user_id, qq_id, created_at)
                       VALUES (%s, %s, %s, %s, %s)""",
                    (request['appid'], request['openid'], user['id'], qq, int(time.time())))
            await cur.execute("DELETE FROM official_link_requests WHERE token_hash = %s", (digest,))
            return 'ok'

    async def revoke_official_links(self, qq: str) -> int:
        """原 QQ 撤销自己的全部官方关联和待确认请求，原角色与 QQ 权限不变。"""
        async with self._identity_cursor('official-revoke:' + qq) as cur:
            await cur.execute("DELETE FROM official_link_requests WHERE owner_qq = %s", (qq,))
            await cur.execute("DELETE FROM official_user_accounts WHERE qq_id = %s", (qq,))
            return cur.rowcount

    async def get_user_by_id(self, user_id: int) -> dict | None:
        rows = await self._query(
            "SELECT id, home_team, name, qq_id FROM users WHERE id = %s",
            (user_id,),
        )
        return rows[0] if rows else None

    async def get_qq_ids_by_names(
        self, home_team: str, names: list[str]
    ) -> dict[str, str]:
        """展示名 → qq_id（**只含 qq_id 非空的**），用于结算公告里的 @。

        按 `users.name` 查，**不是**按 `player_ids.player_name`：排行榜上的
        `player` 是 `COALESCE(u.name, d.player_a)`（§5-M03 的展示名），绑定了角色
        的选手在榜上显示的是**角色名**，用参赛ID去查会一个都匹配不上。

        查不到的（没绑定 / 绑了但没存 QQ / 纯参赛ID）**不出现在返回值里**，
        调用方按「@ 不出来」退化处理，见 `main.settle`。
        """
        if not names:
            return {}
        placeholders = ", ".join(["%s"] * len(names))
        rows = await self._query(
            f"""SELECT name, qq_id FROM users
                WHERE home_team = %s AND name IN ({placeholders}) AND qq_id <> ''""",
            (home_team, *names),
        )
        return {r["name"]: r["qq_id"] for r in rows}

    async def rename_user(self, home_team: str, user_id: int, new_name: str) -> str:
        """修改用户角色名（战队内唯一）。返回状态：'ok' / 'conflict'。"""
        async with self._identity_cursor(home_team) as cur:
            await cur.execute(
                "SELECT id FROM users WHERE home_team = %s AND name = %s AND id != %s",
                (home_team, new_name, user_id),
            )
            if await cur.fetchone():
                return "conflict"
            await cur.execute(
                "UPDATE users SET name = %s WHERE home_team = %s AND id = %s",
                (new_name, home_team, user_id),
            )
            return "ok"

    async def claim_user_by_name(self, home_team: str, name: str, qq_id: str) -> tuple[str, int]:
        """把 QQ 认领到指定名字的用户。

        Returns:
            (状态, user_id)：状态为 'ok'（认领成功/已是本人）、'claimed_else'（已被他人认领）、
            'not_found'（用户不存在，user_id 为 0）。
        """
        async with self._identity_cursor(home_team) as cur:
            await cur.execute(
                "SELECT id, qq_id FROM users WHERE home_team = %s AND name = %s",
                (home_team, name),
            )
            row = await cur.fetchone()
            if not row:
                return "not_found", 0
            uid = row["id"]
            if row["qq_id"] and str(row["qq_id"]) != str(qq_id):
                return "claimed_else", uid
            await cur.execute(
                "SELECT id FROM users WHERE home_team = %s AND qq_id = %s AND id <> %s",
                (home_team, qq_id, uid),
            )
            if await cur.fetchone():
                return "claimed_else", uid
            await cur.execute("UPDATE users SET qq_id = %s WHERE id = %s", (qq_id, uid))
            return "ok", uid

    async def get_player_pool(self, home_team: str, keyword: str | None = None, limit: int = 50) -> list[str]:
        """该战队已入库的参赛ID（发送战报时写入 player_ids），可选模糊匹配。"""
        like = f"%{keyword}%" if keyword else "%"
        rows = await self._query(
            "SELECT player_name FROM player_ids "
            "WHERE home_team = %s AND player_name LIKE %s ORDER BY player_name LIMIT %s",
            (home_team, like, limit),
        )
        return [r["player_name"] for r in rows]

    async def get_pool_status(self, home_team: str, keyword: str | None = None, limit: int = 20) -> list[dict]:
        """参赛ID池及绑定状态（含所属用户）。"""
        pool = await self.get_player_pool(home_team, keyword, limit)
        if not pool:
            return []
        placeholders = ",".join(["%s"] * len(pool))
        rows = await self._query(
            f"""SELECT p.player_name, u.name AS user_name, u.qq_id
                FROM player_ids p LEFT JOIN users u ON p.user_id = u.id
                WHERE p.home_team = %s AND p.player_name IN ({placeholders})""",
            (home_team, *pool),
        )
        bound = {r["player_name"]: r for r in rows}
        result = []
        for p in pool:
            b = bound.get(p)
            result.append({
                "player": p,
                "user_name": b["user_name"] if b else "",
                "qq_id": b["qq_id"] if b else "",
            })
        return result

    async def get_player_binding(self, home_team: str, player_name: str) -> dict | None:
        """查询某个参赛ID的绑定情况。"""
        rows = await self._query(
            """SELECT p.id, p.player_name, p.user_id, u.name AS user_name, u.qq_id
               FROM player_ids p LEFT JOIN users u ON p.user_id = u.id
               WHERE p.home_team = %s AND p.player_name = %s""",
            (home_team, player_name),
        )
        return rows[0] if rows else None

    async def bind_player_to_user(self, home_team: str, player_name: str, user_id: int) -> None:
        """把参赛ID绑定到用户（覆盖）。"""
        async with self._identity_cursor(home_team) as cur:
            await cur.execute("SELECT id FROM users WHERE home_team = %s AND id = %s", (home_team, user_id))
            if not await cur.fetchone():
                raise ValueError("目标角色不属于本战队")
            await cur.execute(
                """INSERT INTO player_ids (home_team, player_name, user_id, created_at)
                   VALUES (%s, %s, %s, %s) AS new
                   ON DUPLICATE KEY UPDATE user_id = new.user_id""",
                (home_team, player_name, user_id, int(time.time())),
            )

    async def unbind_player(self, home_team: str, player_name: str, user_id: int | None = None) -> int:
        """解除参赛ID绑定（user_id 置 NULL）。"""
        async with self._identity_cursor(home_team) as cur:
            owner_clause = " AND user_id = %s" if user_id is not None else ""
            await cur.execute(
                "UPDATE player_ids SET user_id = NULL WHERE home_team = %s AND player_name = %s" + owner_clause,
                (home_team, player_name, user_id) if user_id is not None else (home_team, player_name),
            )
            return cur.rowcount

    async def get_user_players(self, home_team: str, user_id: int) -> list[str]:
        """某用户绑定的参赛ID列表。"""
        rows = await self._query(
            "SELECT player_name FROM player_ids WHERE home_team = %s AND user_id = %s ORDER BY id",
            (home_team, user_id),
        )
        return [r["player_name"] for r in rows]

    async def resolve_role(self, home_team: str, name: str) -> dict | None:
        """把名字解析为角色：name 可以是已绑定的参赛ID 或 角色名。

        命中返回 {"user_name": 角色名, "players": [该角色全部参赛ID]}；无绑定或角色无参赛ID返回 None。
        """
        rows = await self._query(
            """SELECT u.id AS user_id, u.name AS user_name
               FROM player_ids pi JOIN users u ON u.home_team = pi.home_team AND u.id = pi.user_id
               WHERE pi.home_team = %s AND pi.player_name = %s LIMIT 1""",
            (home_team, name),
        )
        if not rows:
            rows = await self._query(
                "SELECT id AS user_id, name AS user_name FROM users WHERE home_team = %s AND name = %s LIMIT 1",
                (home_team, name),
            )
        if not rows:
            return None
        players = await self.get_user_players(home_team, rows[0]["user_id"])
        if not players:
            return None
        return {"user_name": rows[0]["user_name"], "players": players}

    async def get_players_aggregate(
        self,
        home_team: str,
        players: list[str],
        date_from: str | None = None,
        date_to: str | None = None,
    ) -> dict:
        """合并战绩及本期 total>0 的 active_players，踢馆按完整集合重算。"""
        total = {"wins": 0, "losses": 0, "draws": 0, "total": 0, "active_players": []}
        for p in players:
            rec = await self.get_player_record(
                home_team, p, date_from, date_to, with_raid=False
            )
            total["wins"] += int(rec.get("wins", 0))
            total["losses"] += int(rec.get("losses", 0))
            total["draws"] += int(rec.get("draws", 0))
            total["total"] += int(rec.get("total", 0))
            if int(rec.get("total", 0)) > 0:
                total["active_players"].append(p)
        # 友谊次数 = 集合内任一玩家在本战队一侧出场的去重比赛场次数
        # （合并多ID时按比赛去重，避免同一场出现该用户多个ID被重复计）
        total["friendship"] = 0
        if players:
            d1, d2 = self._date_bounds(date_from, date_to)
            ph = ",".join(["%s"] * len(players))
            params = [home_team, d1, d2] + players + [home_team] + players + [home_team]
            frows = await self._query(
                f"""SELECT COUNT(DISTINCT m.id) AS friendship
                    FROM duels d JOIN matches m ON d.match_id = m.id
                    WHERE m.home_team = %s AND m.match_time >= %s AND m.match_time <= %s
                      AND m.kind = 'friendly'
                      AND NOT (d.score_a = 0 AND d.score_b = 0)
                      AND ((d.player_a IN ({ph}) AND d.player_a_team = %s)
                           OR (d.player_b IN ({ph}) AND d.player_b_team = %s))""",
                tuple(params),
            )
            total["friendship"] = int(frows[0]["friendship"] or 0)
        # 踢馆积分在**合并后的ID集合**上按同一套规则重算（不是各ID相加）
        raid = await self.get_raid_stats_for_players(home_team, players, date_from, date_to)
        for key in ("raid_points", "raid_success", "hold", "first_round"):
            total[key] = int(raid.get(key, 0) or 0)
        return total

    # ---------- 聚合统计 ----------

    @staticmethod
    def _date_bounds(date_from: str | None, date_to: str | None) -> tuple[str, str]:
        return (date_from or "1000-01-01", date_to or "9999-12-31")

    async def get_player_ranking(
        self,
        home_team: str,
        date_from: str | None = None,
        date_to: str | None = None,
        min_games: int = 1,
        limit: int = 10,
        team: str | None = None,
    ) -> list[dict]:
        """个人排行（积分 = 胜场 × 胜率，胜率用小数，保留两位），按战队跨群统计。

        team 非空时只统计该战队选手。

        **「积分」列只算友谊赛**；踢馆积分由本方法另行并入 `raid_points`/
        `total_points`，名次按**总积分**排。因此最终排序与截断在 Python 侧做
        （`stats.sort_ranking`）—— SQL 的 `LIMIT` 会先按友谊积分截断，把靠踢馆
        冲上来的选手直接挡在榜外，所以这里**不能**带 LIMIT。

        只在踢馆里出场、没有任何友谊对局的选手不在此榜（`HAVING total >=
        min_games` 的门槛按友谊场次算），但 `/踢馆` 与 `/战绩` 仍能查到他们。
        """
        d1, d2 = self._date_bounds(date_from, date_to)
        params: list = [home_team, d1, d2]
        params += [home_team, d1, d2]
        team_clause = ""
        if team:
            team_clause = "WHERE sides.team = %s "
            params.append(team)
        params.append(min_games)
        rows = await self._query(
            f"""WITH sides AS (
                   SELECT COALESCE(u.name, d.player_a) AS player, d.player_a_team AS team,
                          CASE d.result WHEN 'A' THEN 1 ELSE 0 END AS win,
                          CASE d.result WHEN 'B' THEN 1 ELSE 0 END AS loss,
                          CASE WHEN d.result = 'DRAW' AND NOT (d.score_a = 0 AND d.score_b = 0)
                               THEN 1 ELSE 0 END AS draw
                   FROM duels d JOIN matches m ON d.match_id = m.id
                   LEFT JOIN player_ids pi ON pi.home_team = d.player_a_team AND pi.player_name = d.player_a
                   LEFT JOIN users u ON u.home_team = pi.home_team AND u.id = pi.user_id
                   WHERE m.home_team = %s AND m.match_time >= %s AND m.match_time <= %s
                     AND m.kind = 'friendly'
                   UNION ALL
                   SELECT COALESCE(u.name, d.player_b), d.player_b_team,
                          CASE d.result WHEN 'B' THEN 1 ELSE 0 END,
                          CASE d.result WHEN 'A' THEN 1 ELSE 0 END,
                          CASE WHEN d.result = 'DRAW' AND NOT (d.score_a = 0 AND d.score_b = 0)
                               THEN 1 ELSE 0 END
                   FROM duels d JOIN matches m ON d.match_id = m.id
                   LEFT JOIN player_ids pi ON pi.home_team = d.player_b_team AND pi.player_name = d.player_b
                   LEFT JOIN users u ON u.home_team = pi.home_team AND u.id = pi.user_id
                   WHERE m.home_team = %s AND m.match_time >= %s AND m.match_time <= %s
                     AND m.kind = 'friendly'
               )
               SELECT player, SUM(win) wins, SUM(loss) losses, SUM(draw) draws,
                      COUNT(*) total,
                      ROUND(SUM(win) * SUM(win) / NULLIF(SUM(win)+SUM(loss), 0), 2) AS points
               FROM sides
               {team_clause}
               GROUP BY player HAVING total >= %s
               ORDER BY points DESC, wins DESC, total DESC, player ASC""",
            tuple(params),
        )
        # 合并每人的比赛级统计（友谊次数/无双次数）；team 过滤与 total 列口径一致
        match_stats = await self.get_player_match_stats(home_team, date_from, date_to, team=team)
        for r in rows:
            st = match_stats.get(r["player"], {"friendship": 0, "wushuang": 0})
            r["friendship"] = st["friendship"]
            r["wushuang"] = st["wushuang"]
        # 并入踢馆积分并算出总积分，按总积分重排 + 截断（见 docstring）。
        # 这里的 team 是「只看这一侧的选手」过滤器 → 踢馆侧对应 side_team。
        raid_by_player = await self.get_raid_player_stats(
            home_team, date_from, date_to, side_team=team
        )
        stats.merge_raid_into_ranking(rows, raid_by_player)
        return stats.sort_ranking(rows, limit)

    async def get_player_match_stats(
        self,
        home_team: str,
        date_from: str | None = None,
        date_to: str | None = None,
        team: str | None = None,
    ) -> dict[str, dict]:
        """统计区间内每人参与的比赛场次（友谊次数）与无双次数。

        友谊次数 = 参与的去重比赛场次数（有 ≥1 场非 0:0 对局）。
        无双次数 = 场次级判定（见 stats.compute_match_stats），每场至多一人。
        返回 {已解析玩家名: {"friendship": int, "wushuang": int}}。
        名字解析与 get_player_ranking 的 sides CTE 一致（COALESCE(u.name, 参赛ID)）。

        team 非空时只统计该玩家在 team 一侧出场的比赛（跨队同名碰撞排除，
        与 get_player_ranking 的 team_clause / total 列口径一致）。
        """
        d1, d2 = self._date_bounds(date_from, date_to)
        rows = await self._query(
            """SELECT m.id AS match_id, m.winner, m.rule,
                      d.seq, d.round_no, d.score_a, d.score_b,
                      d.player_a_team, d.player_b_team,
                      COALESCE(ua.name, d.player_a) AS resolved_a,
                      COALESCE(ub.name, d.player_b) AS resolved_b
               FROM matches m
               LEFT JOIN duels d ON d.match_id = m.id
               LEFT JOIN player_ids pia
                      ON pia.home_team = d.player_a_team AND pia.player_name = d.player_a
               LEFT JOIN users ua ON ua.home_team = pia.home_team AND ua.id = pia.user_id
               LEFT JOIN player_ids pib
                      ON pib.home_team = d.player_b_team AND pib.player_name = d.player_b
               LEFT JOIN users ub ON ub.home_team = pib.home_team AND ub.id = pib.user_id
               WHERE m.home_team = %s AND m.match_time >= %s AND m.match_time <= %s
                 AND m.kind = 'friendly'
               ORDER BY m.id, d.seq, d.id""",
            (home_team, d1, d2),
        )
        totals: dict[str, dict] = {}
        cur: list[dict] = []
        cur_id: int | None = None
        cur_winner = ""
        cur_rule = ""

        def flush() -> None:
            if not cur:
                return
            # rule 只影响无双的数据兜底是否启用（仅 KOF 适用），见 compute_match_stats
            st = stats.compute_match_stats(cur, cur_winner, cur_rule)
            if team:
                # 只统计在该战队一侧出场的玩家：跨队同名（如两队都有 知更）不计入本队
                on_team = set()
                for d in cur:
                    if d["player_a_team"] == team:
                        on_team.add(d["resolved_a"])
                    if d["player_b_team"] == team:
                        on_team.add(d["resolved_b"])
                for name in list(st):
                    if name not in on_team:
                        del st[name]
            for name, v in st.items():
                t = totals.setdefault(name, {"friendship": 0, "wushuang": 0})
                t["friendship"] += v["friendship"]
                t["wushuang"] += v["wushuang"]

        for r in rows:
            if r["match_id"] != cur_id:
                flush()
                # ⚠️ 三者必须一起重置：flush() 是闭包，漏掉任何一个都会把上一场比赛
                # 的值静默带进下一场（不报错，只是算错）。
                cur, cur_id, cur_winner, cur_rule = (
                    [], r["match_id"], r["winner"] or "", r["rule"] or "",
                )
            if r["resolved_a"] is None:  # LEFT JOIN：该比赛无对局
                continue
            cur.append({
                "seq": int(r["seq"] or 0),
                "round_no": int(r["round_no"] or 1),
                "score_a": r["score_a"],
                "score_b": r["score_b"],
                "player_a_team": r["player_a_team"],
                "player_b_team": r["player_b_team"],
                "resolved_a": r["resolved_a"],
                "resolved_b": r["resolved_b"],
            })
        flush()
        return totals

    async def get_player_record(
        self,
        home_team: str,
        player: str,
        date_from: str | None = None,
        date_to: str | None = None,
        with_raid: bool = True,
    ) -> dict:
        """单个玩家的战绩汇总，按战队跨群统计。

        同时限定该选手属于该战队（避免同名不同队选手混入）。
        友谊次数 = 该玩家在本战队一侧出场的去重比赛场次数（有 ≥1 场非 0:0 对局）。
        with_raid=False 时跳过踢馆积分（`get_players_aggregate` 自己合并多ID时用，
        避免每个ID各扫一遍踢馆表）。
        """
        d1, d2 = self._date_bounds(date_from, date_to)
        params: list = [player, d1, d2, home_team, home_team]
        params += [player, d1, d2, home_team, home_team]
        params.append(player)
        rows = await self._query(
            f"""WITH sides AS (
                   SELECT CASE d.result WHEN 'A' THEN 1 ELSE 0 END AS win,
                          CASE d.result WHEN 'B' THEN 1 ELSE 0 END AS loss,
                          CASE WHEN d.result = 'DRAW' AND NOT (d.score_a = 0 AND d.score_b = 0)
                               THEN 1 ELSE 0 END AS draw
                   FROM duels d JOIN matches m ON d.match_id = m.id
                   WHERE d.player_a = %s
                     AND m.match_time >= %s AND m.match_time <= %s
                     AND m.home_team = %s AND d.player_a_team = %s
                     AND m.kind = 'friendly'
                   UNION ALL
                   SELECT CASE d.result WHEN 'B' THEN 1 ELSE 0 END,
                          CASE d.result WHEN 'A' THEN 1 ELSE 0 END,
                          CASE WHEN d.result = 'DRAW' AND NOT (d.score_a = 0 AND d.score_b = 0)
                               THEN 1 ELSE 0 END
                   FROM duels d JOIN matches m ON d.match_id = m.id
                   WHERE d.player_b = %s
                     AND m.match_time >= %s AND m.match_time <= %s
                     AND m.home_team = %s AND d.player_b_team = %s
                     AND m.kind = 'friendly'
               )
               SELECT player_name AS player,
                      SUM(win) wins, SUM(loss) losses, SUM(draw) draws, COUNT(*) total
               FROM (SELECT %s AS player_name, win, loss, draw FROM sides) t
               GROUP BY player_name""",
            tuple(params),
        )
        result = rows[0] if rows else {"player": player, "wins": 0, "losses": 0, "draws": 0, "total": 0}
        # 友谊次数：该玩家在本战队一侧出场的去重比赛场次数（有 ≥1 场非 0:0 对局）
        frows = await self._query(
            """SELECT COUNT(DISTINCT m.id) AS friendship
               FROM duels d JOIN matches m ON d.match_id = m.id
               WHERE m.home_team = %s AND m.match_time >= %s AND m.match_time <= %s
                 AND m.kind = 'friendly'
                 AND NOT (d.score_a = 0 AND d.score_b = 0)
                 AND ((d.player_a = %s AND d.player_a_team = %s)
                      OR (d.player_b = %s AND d.player_b_team = %s))""",
            (home_team, d1, d2, player, home_team, player, home_team),
        )
        result["friendship"] = int(frows[0]["friendship"] or 0)
        result["raid_points"] = 0
        if with_raid:
            # 踢馆积分（独立于友谊口径的胜负；按「同一套规则按人重算」得出）。
            # 传进来的是参赛ID，踢馆侧按已解析名聚合，先按 M-03 解析一次。
            resolved = (await self._resolve_player_names(home_team, [player]))[player]
            raid = await self.get_raid_player_stats(
                home_team, date_from, date_to, side_team=home_team
            )
            mine = raid.get(resolved, {})
            result["raid_points"] = int(mine.get("raid_points", 0))
            # 三个计数字段供 `/战绩` 展示（与排行末三列同源，取不到时按 0）
            result["raid_success"] = int(mine.get("raid_success", 0))
            result["hold"] = int(mine.get("hold", 0))
            result["first_round"] = int(mine.get("first_round", 0))
        return result

    async def get_home_team_vs_opponents(
        self,
        home_team: str,
        date_from: str | None = None,
        date_to: str | None = None,
    ) -> list[dict]:
        """主体战队对战各对手的胜负记录（按战队跨群），返回 [{opponent, wins, losses, total, win_rate, raid_points}]。

        `raid_points` 是该对手的交手踢馆积分（踢馆方按对手队取最高那场，与
        `stats.aggregate_raid` 的月度降重口径一致），没有踢馆记录时为 0。
        胜负列**不含**踢馆（那走 raid_points）。
        """
        d1, d2 = self._date_bounds(date_from, date_to)
        rows = await self._query(
            """SELECT opponent,
                      SUM(CASE WHEN winner = %s THEN 1 ELSE 0 END) AS wins,
                      SUM(CASE WHEN winner != %s THEN 1 ELSE 0 END) AS losses,
                      COUNT(*) AS total
               FROM (
                   SELECT CASE WHEN m.team_a = %s THEN m.team_b ELSE m.team_a END AS opponent,
                          m.winner
                   FROM matches m
                   WHERE m.home_team = %s AND (m.team_a = %s OR m.team_b = %s)
                     AND m.winner != '' AND m.match_time >= %s AND m.match_time <= %s
                     AND m.kind = 'friendly'
               ) t
               GROUP BY opponent
               ORDER BY total DESC, wins DESC""",
            (home_team, home_team, home_team, home_team, home_team, home_team, d1, d2),
        )
        raid = await self.get_raid_points_by_opponent(home_team, date_from, date_to)
        result = []
        for r in rows:
            w, l = int(r["wins"] or 0), int(r["losses"] or 0)
            total = int(r["total"] or 0)
            wr = round(w * 100.0 / (w + l), 1) if (w + l) else 0.0
            result.append({
                "opponent": r["opponent"], "wins": w, "losses": l,
                "total": total, "win_rate": wr,
                "raid_points": int(raid.get(r["opponent"], 0)),
            })
        # 只在友谊赛里交手过、但有过踢馆的对手：补进列表（否则踢馆分无处显示）
        for opp, pts in raid.items():
            if pts and opp not in {x["opponent"] for x in result}:
                result.append({
                    "opponent": opp, "wins": 0, "losses": 0,
                    "total": 0, "win_rate": 0.0, "raid_points": int(pts),
                })
        return result

    async def get_home_team_record(
        self,
        home_team: str,
        date_from: str | None = None,
        date_to: str | None = None,
    ) -> dict:
        """主体战队总体战绩（按胜者判定，按战队跨群），返回 {wins, losses, draws, total, win_rate, raid_points, total_points, attack_points, raid_success, hold, first_round}。

        胜/负/总**只统计友谊赛**（踢馆有自己的积分，见 `raid_points`）。
        踢馆口径与 get_raid_team_stats 一致：按 `(team_a = T OR team_b = T)`
        对称取数 —— 只有这样才能让守馆方也拿到分（M-02 的唯一例外）。
        末三个计数字段供 `/战队战绩` 展示，`attack_points` 供 `/排行` 图片左侧的
        战队面板（`stats.build_team_panel`）—— 都直接透传 `get_raid_team_stats`。

        ⚠️ `raid_points` 是**封顶后**的踢馆积分（= attack + min(10, 守馆加点)），
        `attack_points` 是**未封顶**的踢馆加点。面板要的是后者，别拿错。
        """
        d1, d2 = self._date_bounds(date_from, date_to)
        rows = await self._query(
            """SELECT COUNT(*) AS total,
                      SUM(CASE WHEN winner = %s THEN 1 ELSE 0 END) AS wins,
                      SUM(CASE WHEN winner != %s THEN 1 ELSE 0 END) AS losses
               FROM matches m
               WHERE m.home_team = %s AND m.winner != ''
                 AND m.match_time >= %s AND m.match_time <= %s
                 AND m.kind = 'friendly'""",
            (home_team, home_team, home_team, d1, d2),
        )
        r = rows[0] if rows else {}
        total = int(r.get("total") or 0)
        wins = int(r.get("wins") or 0)
        losses = int(r.get("losses") or 0)
        wr = round(wins * 100.0 / (wins + losses), 1) if (wins + losses) else 0.0
        raid = await self.get_raid_team_stats(home_team, date_from, date_to)
        return {
            "wins": wins, "losses": losses, "draws": 0, "total": total, "win_rate": wr,
            "raid_points": raid["raid_points"],
            "total_points": stats.total_points(stats._points(wins, losses), raid["raid_points"]),
            "attack_points": raid["attack_points"],
            "raid_success": raid["raid_success"],
            "hold": raid["hold"],
            "first_round": raid["first_round"],
        }

    async def get_player_trend(
        self,
        home_team: str,
        player: str,
        date_from: str | None = None,
        date_to: str | None = None,
        side_team: str | None = None,
    ) -> list[tuple[str, int, int]]:
        """个人按日期的胜/负场次；可限定选手所属队伍，避免跨队同名。"""
        d1, d2 = self._date_bounds(date_from, date_to)
        date_clause = " AND m.match_time <= %s" if date_to else ""
        a_clause = " AND d.player_a_team = %s" if side_team else ""
        b_clause = " AND d.player_b_team = %s" if side_team else ""
        params = [home_team, player, d1]
        if date_to:
            params.append(d2)
        if side_team:
            params.append(side_team)
        params += [home_team, player, d1]
        if date_to:
            params.append(d2)
        if side_team:
            params.append(side_team)
        rows = await self._query(
            f"""SELECT m.match_time AS date,
                      SUM(CASE WHEN d.result='A' THEN 1 ELSE 0 END) AS wins,
                      SUM(CASE WHEN d.result='B' THEN 1 ELSE 0 END) AS losses
               FROM duels d JOIN matches m ON d.match_id = m.id
               WHERE m.home_team = %s AND d.player_a = %s AND m.match_time >= %s
                 AND m.kind = 'friendly'{date_clause}{a_clause}
               GROUP BY m.match_time
               UNION ALL
               SELECT m.match_time,
                      SUM(CASE WHEN d.result='B' THEN 1 ELSE 0 END),
                      SUM(CASE WHEN d.result='A' THEN 1 ELSE 0 END)
               FROM duels d JOIN matches m ON d.match_id = m.id
               WHERE m.home_team = %s AND d.player_b = %s AND m.match_time >= %s
                 AND m.kind = 'friendly'{date_clause}{b_clause}
               GROUP BY m.match_time""",
            tuple(params),
        )
        merged: dict[str, list[int]] = {}
        for row in rows:
            key = str(row["date"])
            if key not in merged:
                merged[key] = [0, 0]
            merged[key][0] += int(row["wins"] or 0)
            merged[key][1] += int(row["losses"] or 0)
        return [(d, w, l) for d, (w, l) in sorted(merged.items())]

    async def get_players_trend(
        self,
        home_team: str,
        players: list[str],
        date_from: str | None = None,
        date_to: str | None = None,
    ) -> list[tuple[str, int, int]]:
        """多个参赛ID合并按日期的胜/负场次（按战队跨群，限定战队避免同名混淆），返回 [(date, wins, losses)]。"""
        if not players:
            return []
        d1, d2 = self._date_bounds(date_from, date_to)
        ph = ",".join(["%s"] * len(players))
        date_clause = " AND m.match_time <= %s" if date_to else ""
        params = [home_team, d1, home_team]
        params += list(players)
        if date_to:
            params.append(d2)
        params += [home_team, d1, home_team]
        params += list(players)
        if date_to:
            params.append(d2)
        rows = await self._query(
            f"""SELECT m.match_time AS date,
                      SUM(CASE WHEN d.result='A' THEN 1 ELSE 0 END) AS wins,
                      SUM(CASE WHEN d.result='B' THEN 1 ELSE 0 END) AS losses
               FROM duels d JOIN matches m ON d.match_id = m.id
               WHERE m.home_team = %s AND m.match_time >= %s
                 AND m.kind = 'friendly'
                 AND d.player_a_team = %s AND d.player_a IN ({ph}){date_clause}
               GROUP BY m.match_time
               UNION ALL
               SELECT m.match_time,
                      SUM(CASE WHEN d.result='B' THEN 1 ELSE 0 END),
                      SUM(CASE WHEN d.result='A' THEN 1 ELSE 0 END)
               FROM duels d JOIN matches m ON d.match_id = m.id
               WHERE m.home_team = %s AND m.match_time >= %s
                 AND m.kind = 'friendly'
                 AND d.player_b_team = %s AND d.player_b IN ({ph}){date_clause}
               GROUP BY m.match_time""",
            tuple(params),
        )
        merged: dict[str, list[int]] = {}
        for row in rows:
            key = str(row["date"])
            if key not in merged:
                merged[key] = [0, 0]
            merged[key][0] += int(row["wins"] or 0)
            merged[key][1] += int(row["losses"] or 0)
        return [(d, w, l) for d, (w, l) in sorted(merged.items())]

    async def get_team_trend(
        self,
        home_team: str,
        team: str,
        date_from: str | None = None,
        date_to: str | None = None,
    ) -> list[tuple[str, int, int]]:
        """队伍按日期的胜/负场次（按战队跨群），返回 [(date, wins, losses)]。"""
        d1, d2 = self._date_bounds(date_from, date_to)
        rows = await self._query(
            """SELECT m.match_time AS date,
                      SUM(CASE WHEN m.winner = %s THEN 1 ELSE 0 END) AS wins,
                      SUM(CASE WHEN m.winner <> %s THEN 1 ELSE 0 END) AS losses
               FROM matches m
               WHERE m.home_team = %s AND (m.team_a = %s OR m.team_b = %s)
                 AND m.kind = 'friendly' AND m.winner <> ''
                 AND m.match_time >= %s AND m.match_time <= %s
               GROUP BY m.match_time ORDER BY m.match_time""",
            (team, team, home_team, team, team, d1, d2),
        )
        return [(str(r["date"]), int(r["wins"] or 0), int(r["losses"] or 0)) for r in rows]

    # ---------- 月度结算（settlement） ----------

    async def set_settlement(
        self, home_team: str, month: str, entries: list[dict]
    ) -> None:
        """覆盖写入本队单月快照，复用多月事务。"""
        await self.set_settlements(home_team, [(month, entries)])

    async def set_settlements(
        self, home_team: str, settlements: list[tuple[str, list[dict]]]
    ) -> None:
        """本次各月在同一事务内覆盖；任意一月失败则全部回滚。"""
        assert self.pool is not None
        now = int(time.time())
        async with self.pool.acquire() as conn:
            await conn.begin()
            try:
                async with conn.cursor() as cur:
                    for month, entries in settlements:
                        await cur.execute(
                            "DELETE FROM settlements WHERE home_team = %s AND month = %s",
                            (home_team, month),
                        )
                        for e in entries:
                            await cur.execute(
                                """INSERT INTO settlements
                                   (home_team, month, player_name, rank_no,
                                    total_points, bonus, created_at)
                                   VALUES (%s, %s, %s, %s, %s, %s, %s)""",
                                (
                                    home_team,
                                    month,
                                    e["player"],
                                    int(e["rank_no"]),
                                    e.get("total_points", 0) or 0,
                                    e.get("bonus", 0) or 0,
                                    now,
                                ),
                            )
                await conn.commit()
            except BaseException:
                await conn.rollback()
                raise

    async def clear_settlement(self, home_team: str, month: str) -> int:
        """删掉某队某月的结算记录，把该月恢复成**未结算**。返回删掉的行数。

        `set_settlement` 里那句 DELETE 是「重算前先清空」的中间步骤；这个方法是
        把它单独暴露出来当**终点**用（`/重置结算`）：删完不补 INSERT，于是
        `/排行` 回到 14 列、`/结算` 又可以被当成「该月第一次结算」重新发公告。

        返回 0 = 该月本来就没结算过，调用方据此回「无需重置」（不报错）。
        只删本队本月，别队别月不受影响。
        """
        return await self._execute(
            "DELETE FROM settlements WHERE home_team = %s AND month = %s",
            (home_team, month),
        )

    async def get_settlement(self, home_team: str, month: str) -> dict[str, float]:
        """某队某月的结算结果 `{玩家名: 奖金}`。

        没结算过时返回**空 dict** —— 调用方（`/排行`）据此决定要不要显示「奖金」
        列：空 = 这个月还没结算 = 不加那一列。
        """
        rows = await self._query(
            """SELECT player_name, bonus FROM settlements
               WHERE home_team = %s AND month = %s""",
            (home_team, month),
        )
        return {r["player_name"]: float(r["bonus"] or 0) for r in rows}

    async def get_settlement_entries(self, home_team: str, month: str) -> list[dict]:
        """某队某月已结算结果的**明细**（按名次升序），供只读查询用。

        没结算过时返回**空列表**。

        与 `get_settlement` 的区别：那个只给 `{玩家名: 奖金}`（`/排行` 拿来判断
        要不要加「奖金」列），这个给的是完整回执所需的
        rank_no / player / total_points / bonus 四个字段。

        ⚠️ `total_points` 落库时被 `DECIMAL(10,2)` 截到 2 位小数，所以回显值
        可能与实时榜单的 `:g` 值差在小数点后第 3 位 —— 这是**快照**，以库里的为准。
        """
        rows = await self._query(
            """SELECT rank_no, player_name, total_points, bonus FROM settlements
               WHERE home_team = %s AND month = %s ORDER BY rank_no""",
            (home_team, month),
        )
        return [
            {
                "rank_no": int(r["rank_no"]),
                "player": r["player_name"],
                "total_points": float(r["total_points"] or 0),
                "bonus": float(r["bonus"] or 0),
            }
            for r in rows
        ]

    # ---------- 踢馆赛（raid） ----------

    async def get_raid_matches(
        self, team: str, date_from: str | None = None, date_to: str | None = None
    ) -> list[dict]:
        """某战队参与的踢馆报（含对局），返回按战报聚合的 dict 列表。

        ⚠️ **按 `team_a`/`team_b` 对称取数，不看 `home_team`** —— 这是 M-02
        「统计按 `home_team` 跨群聚合」的**唯一例外**。踢馆报的 `home_team` 只是
        提交方（通常是踢馆方），照 M-02 取数的话守馆方永远拿不到守馆积分。
        跨群的同一支战队因此能看到彼此的踢馆记录，与友谊赛一致。

        玩家名按 M-03 解析（`COALESCE(u.name, 参赛ID)`）。占位行（防守方为
        `规则`）照常返回，由 `stats.compute_raid_match` 排除。
        """
        d1, d2 = self._date_bounds(date_from, date_to)
        rows = await self._query(
            """SELECT m.id AS match_id, m.team_a, m.team_b, m.winner, m.rule,
                      m.match_time,
                      d.seq, d.round_no, d.score_a, d.score_b,
                      d.player_a, d.player_b, d.owner,
                      COALESCE(ua.name, d.player_a) AS resolved_a,
                      COALESCE(ub.name, d.player_b) AS resolved_b
               FROM matches m
               LEFT JOIN duels d ON d.match_id = m.id
               LEFT JOIN player_ids pia
                      ON pia.home_team = m.team_a AND pia.player_name = d.player_a
               LEFT JOIN users ua ON ua.home_team = pia.home_team AND ua.id = pia.user_id
               LEFT JOIN player_ids pib
                      ON pib.home_team = m.team_b AND pib.player_name = d.player_b
               LEFT JOIN users ub ON ub.home_team = pib.home_team AND ub.id = pib.user_id
               WHERE m.kind = %s AND (m.team_a = %s OR m.team_b = %s)
                 AND m.match_time >= %s AND m.match_time <= %s
               ORDER BY m.id, d.seq, d.id""",
            (KIND_RAID, team, team, d1, d2),
        )
        matches: list[dict] = []
        current: dict | None = None
        for r in rows:
            if current is None or current["match_id"] != r["match_id"]:
                current = {
                    "match_id": r["match_id"],
                    "team_a": r["team_a"],
                    "team_b": r["team_b"],
                    "winner": r["winner"] or "",
                    "rule": r["rule"] or "",
                    "match_time": str(r["match_time"]),
                    "duels": [],
                }
                matches.append(current)
            if r["player_a"] is None:  # LEFT JOIN：该战报没有对局
                continue
            current["duels"].append({
                "seq": int(r["seq"] or 0),
                "round_no": int(r["round_no"] or 0),
                "score_a": int(r["score_a"]),
                "score_b": int(r["score_b"]),
                "player_a": r["player_a"],
                "player_b": r["player_b"],
                "owner": bool(r["owner"]),
                "resolved_a": r["resolved_a"],
                "resolved_b": r["resolved_b"],
            })
        return matches

    async def _raid_infos(
        self, team: str, date_from: str | None = None, date_to: str | None = None
    ) -> list[dict]:
        """区间内某战队参与的全部踢馆的判定结果（`stats.compute_raid_match` 输出）。

        回填 `match_id`，供个人侧「同一场只算一次」去重（一名用户的多个参赛ID
        可能同时出现在同一场踢馆里）。
        """
        infos = []
        for m in await self.get_raid_matches(team, date_from, date_to):
            info = stats.compute_raid_match(m["duels"], m["winner"], m["team_a"], m["team_b"])
            info["match_id"] = m["match_id"]
            infos.append(info)
        return infos

    async def _raid_views_by_player(
        self, team: str, date_from: str | None, date_to: str | None, side_team: str | None
    ) -> dict[str, list[dict]]:
        """{已解析玩家名: [视角记录]}。

        「取哪些战报」由 `team` 决定（对称取数，见 `get_raid_matches`）；
        「取哪一侧的人」由 `side_team` 决定，与前者**互相独立**：

        - `side_team=None` → **不按阵营过滤**，两侧的人都收
          （对应 `get_player_ranking(team=None)` 的「不按队伍过滤」口径）
        - `side_team="KC"` → 只收 KC 自己这一侧（踢馆方记踢馆成功、终结踢馆者的
          那名防守者记守馆成功），避免跨队同名互相串分

        ⚠️ 别把 `side_team` 缺省写成 `team` —— 那会让 `/排行 全部` 悄悄退化成
        「只看本队」，与它同一次查询里友谊口径的选手集合对不上。
        """
        per_player: dict[str, list[dict]] = {}
        for info in await self._raid_infos(team, date_from, date_to):
            for name, view in stats.raid_player_views(info):
                if side_team is not None and view.get("team") != side_team:
                    continue
                per_player.setdefault(name, []).append(view)
        return per_player

    async def get_raid_team_stats(
        self, team: str, date_from: str | None = None, date_to: str | None = None
    ) -> dict:
        """战队级踢馆汇总（`stats.aggregate_raid` 的返回值：4 个计数 + 徽章 + 积分）。

        4 个计数字段 = 踢馆成功 / 踢馆成功含馆主 / 守馆成功 / 守馆首轮，
        另有 `shutdown`（SHUT DOWN 次数）与 `badge`（无人守馆次数）。
        """
        views = []
        for info in await self._raid_infos(team, date_from, date_to):
            v = stats.raid_team_view(info, team)
            if v:
                views.append(v)
        return stats.aggregate_raid(views)

    async def get_raid_player_stats(
        self,
        team: str,
        date_from: str | None = None,
        date_to: str | None = None,
        side_team: str | None = None,
    ) -> dict[str, dict]:
        """个人级踢馆汇总，返回 {已解析玩家名: aggregate_raid 结果}。

        **同一套规则按人重算**（含当月重复踢同一队取最高、守馆封顶 10），不是
        把场次直接相加 —— 既定口径。

        战报集合是 `team` 参与过的全部踢馆（对称取数）；`side_team` 再按阵营
        过滤出场者：踢馆方记踢馆成功与加点，终结踢馆者的那名防守者记守馆
        成功/首轮/SHUT DOWN。**`side_team=None` 表示不按阵营过滤**（两侧都收，
        与 `get_player_ranking(team=None)` 同口径）；要只看某一侧就显式传进来。
        """
        per_player = await self._raid_views_by_player(team, date_from, date_to, side_team)
        return {name: stats.aggregate_raid(views) for name, views in per_player.items()}

    async def get_raid_stats_for_players(
        self,
        team: str,
        players: list[str],
        date_from: str | None = None,
        date_to: str | None = None,
    ) -> dict:
        """把一名用户绑定的多个参赛ID合并为**一份**踢馆汇总（`aggregate_raid` 结果）。

        合并后再套规则，而不是把各ID的汇总相加：同一个人挂多个ID时，「当月重复
        踢穿同一战队取最高」「守馆封顶 10」都要在合并后的集合上算，否则会重复
        计分。同一场踢馆里出现该用户的多个ID时按 `(match_id, 阵营)` 去重。
        """
        if not players:
            return stats.aggregate_raid([])
        per_player = await self._raid_views_by_player(team, date_from, date_to, team)
        resolved = await self._resolve_player_names(team, players)
        views: list[dict] = []
        seen: set[tuple] = set()
        for p in players:
            for v in per_player.get(resolved[p], []):
                key = (v.get("match_id"), v.get("team"))
                if key in seen:
                    continue
                seen.add(key)
                views.append(v)
        return stats.aggregate_raid(views)

    async def _resolve_player_names(self, home_team: str, players: list[str]) -> dict[str, str]:
        """参赛ID → 已解析名（M-03：`COALESCE(u.name, 参赛ID)`），未收录的原样返回。

        踢馆侧按已解析名聚合（与排行行同名），而调用方拿到的是参赛ID，查分前
        必须先走这一步，否则用户改过名就对不上号。
        """
        if not players:
            return {}
        ph = ",".join(["%s"] * len(players))
        rows = await self._query(
            f"""SELECT p.player_name, COALESCE(u.name, p.player_name) AS resolved
                FROM player_ids p LEFT JOIN users u ON u.id = p.user_id
                WHERE p.home_team = %s AND p.player_name IN ({ph})""",
            (home_team, *players),
        )
        mapping = {r["player_name"]: r["resolved"] for r in rows}
        return {p: mapping.get(p, p) for p in players}

    async def get_raid_points_by_opponent(
        self, team: str, date_from: str | None = None, date_to: str | None = None
    ) -> dict[str, int]:
        """对战各对手的**踢馆加点**（踢馆方视角，按对手队取最高那场），供 `/排行 队伍` 展示。

        只含踢馆加点，不含守馆加点 —— 守馆是月度封顶的总额，摊不到单个对手头上。
        """
        best: dict[str, int] = {}
        for info in await self._raid_infos(team, date_from, date_to):
            v = stats.raid_team_view(info, team)
            if v and v["raid_success"]:
                opp = str(v["opponent"])
                best[opp] = max(best.get(opp, 0), int(v["attack_points"]))
        return best

    async def get_export_rows(self, home_team: str, date_from: str | None = None, date_to: str | None = None) -> list[dict]:
        """导出某战队战报（matches + duels 联表），按战队跨群，可按日期过滤。

        **不按 `kind` 过滤**：踢馆战报同样要能导出（`m.kind` 随行返回，
        调用方按需区分）。
        """
        d1, d2 = self._date_bounds(date_from, date_to)
        date_clause = " AND m.match_time >= %s AND m.match_time <= %s" if (date_from or date_to) else ""
        params = [home_team]
        if date_from or date_to:
            params += [d1, d2]
        return await self._query(
            f"""SELECT m.id AS match_id, m.group_id, m.team_a, m.team_b,
                      m.match_time, m.rule, m.location, m.kind, m.export_sent,
                      d.round_no, d.player_a, d.score_a, d.player_b, d.score_b, d.result,
                      d.a_sub, d.b_sub, d.ruled, d.owner
               FROM matches m LEFT JOIN duels d ON d.match_id = m.id
               WHERE m.home_team = %s{date_clause}
               ORDER BY m.id, d.round_no, d.seq, d.id""",
            tuple(params),
        )

    async def get_comparison_reports(self, home_team: str, date_from: str, date_to: str) -> list[dict]:
        """只读核对快照，保留每场对局的实际战队侧，不改变普通导出字段。"""
        return await self.get_reports_for_export(home_team, date_from, date_to, include_team_sides=True)

    async def get_reports_for_export(self, home_team: str, date_from: str | None = None, date_to: str | None = None,
                                     *, include_team_sides: bool = False, match_ids: list[int] | None = None,
                                     include_upload_info: bool = False) -> list[dict]:
        """按战报聚合返回某战队战报（含原始文本与按 seq 排序的对局），供合并转发导出，按战队跨群、可按日期过滤。

        每份战报一个 dict：match_id / team_a / team_b / match_time / rule / location /
        winner / home_team / raw_text / submitted_by / submitted_name / duels。
        """
        d1, d2 = self._date_bounds(date_from, date_to)
        date_clause = " AND m.match_time >= %s AND m.match_time <= %s" if (date_from or date_to) else ""
        params = [home_team]
        if date_from or date_to:
            params += [d1, d2]
        id_clause = ''
        if match_ids is not None:
            if not match_ids:
                return []
            id_clause = ' AND m.id IN (' + ','.join(['%s'] * len(match_ids)) + ')'
            params += match_ids
        team_columns = ', d.player_a_team, d.player_b_team' if include_team_sides else ''
        upload_columns = ', m.group_id, m.created_at' if include_upload_info else ''
        rows = await self._query(
            f"""SELECT m.id AS match_id, m.team_a, m.team_b, m.match_time, m.rule, m.location,
                      m.winner, m.home_team, m.raw_text, m.submitted_by, m.submitted_name,
                      m.kind, m.export_sent,
                      d.seq, d.round_no, d.player_a, d.score_a, d.player_b, d.score_b,
                      d.a_sub, d.b_sub, d.ruled, d.owner{team_columns}{upload_columns}
               FROM matches m LEFT JOIN duels d ON d.match_id = m.id
               WHERE m.home_team = %s{date_clause}{id_clause}
               ORDER BY m.id, d.seq, d.id""",
            tuple(params),
        )
        reports: list[dict] = []
        current: dict | None = None
        for r in rows:
            if current is None or current["match_id"] != r["match_id"]:
                current = {
                    "match_id": r["match_id"],
                    "team_a": r["team_a"],
                    "team_b": r["team_b"],
                    "match_time": str(r["match_time"]),
                    "rule": r["rule"],
                    "location": r["location"],
                    "winner": r["winner"] or "",
                    "home_team": r["home_team"] or "",
                    "raw_text": r["raw_text"] or "",
                    "submitted_by": r["submitted_by"] or "",
                    "submitted_name": r["submitted_name"] or "",
                    "kind": r["kind"] or KIND_FRIENDLY,
                    "export_sent": bool(r["export_sent"]),
                    "duels": [],
                }
                reports.append(current)
                if include_upload_info:
                    current.update(group_id=r['group_id'], created_at=int(r['created_at']))
            if r["player_a"] is not None:
                current["duels"].append({
                    "seq": r["seq"] or 0,
                    "round_no": r["round_no"],
                    "player_a": r["player_a"],
                    "score_a": r["score_a"],
                    "player_b": r["player_b"],
                    "score_b": r["score_b"],
                    "a_sub": bool(r["a_sub"]),
                    "b_sub": bool(r["b_sub"]),
                    "ruled": bool(r["ruled"]),
                    "owner": bool(r["owner"]),
                })
                if include_team_sides:
                    current['duels'][-1].update(player_a_team=r['player_a_team'], player_b_team=r['player_b_team'])
        return reports

    async def get_webui_local_reports(self, home_team: str, start: str, end: str, kind: str,
                                       offset: int, limit: int, *, outcome: str = 'all') -> dict:
        """本地上传列表；先分页比赛ID，再读取所选页对局，避免按duel分页。"""
        where = 'home_team = %s AND match_time BETWEEN %s AND %s'
        params = [home_team, start, end]
        if kind != 'all':
            if kind not in ('friendly', 'raid'):
                raise ValueError('战报类型无效。')
            where += ' AND kind = %s'
            params.append(kind)
        if outcome not in ('all', 'win', 'loss'):
            raise ValueError('胜负筛选无效。')
        if outcome != 'all':
            where += ' AND home_team IN (team_a, team_b) AND winner IN (team_a, team_b)'
            where += ' AND winner = home_team' if outcome == 'win' else ' AND winner <> home_team'
        count = await self._query('SELECT COUNT(*) AS n FROM matches WHERE ' + where, tuple(params))
        ids = await self._query('SELECT id FROM matches WHERE ' + where + ' ORDER BY id DESC LIMIT %s OFFSET %s',
                                tuple(params + [limit, offset]))
        reports = await self.get_webui_local_reports_by_ids(home_team, [int(r['id']) for r in ids])
        return dict(total=int(count[0]['n']), records=sorted(reports, key=lambda r: r['match_id'], reverse=True))

    async def get_daily_friendly_counts(self, home_team: str, start: str, end: str) -> list[dict]:
        """Count whole matches across groups; return monthly counts without paging."""
        return await self._query(
            """SELECT match_time, team_a, team_b, winner, COUNT(*) AS match_count
               FROM matches WHERE home_team = %s AND kind = 'friendly'
                 AND match_time BETWEEN %s AND %s
               GROUP BY match_time, team_a, team_b, winner""", (home_team, start, end))

    async def get_daily_friendly_reports(self, home_team: str, day: str, opponent: str,
                                         offset: int, limit: int) -> dict:
        """Only counted friendly matches for the requested day and opponent."""
        a, b, winner = (f'UPPER(TRIM({column})) COLLATE utf8mb4_bin' for column in ('team_a', 'team_b', 'winner'))
        where = f"""home_team = %s AND kind = 'friendly' AND match_time = %s
                    AND {a} <> {b} AND {winner} IN ({a}, {b})
                    AND (({a} = %s AND {b} = %s) OR ({b} = %s AND {a} = %s))"""
        home_key, opponent_key = home_team.strip().upper(), opponent.strip().upper()
        params = (home_team, day, home_key, opponent_key, home_key, opponent_key)
        count = await self._query('SELECT COUNT(*) AS n FROM matches WHERE ' + where, params)
        ids = await self._query('SELECT id FROM matches WHERE ' + where + ' ORDER BY id DESC LIMIT %s OFFSET %s',
                                params + (limit, offset))
        reports = await self.get_webui_local_reports_by_ids(home_team, [int(r['id']) for r in ids])
        return dict(total=int(count[0]['n']), records=sorted(reports, key=lambda r: r['match_id'], reverse=True))

    async def get_webui_local_reports_by_ids(self, home_team: str, ids: list[int]) -> list[dict]:
        return await self.get_reports_for_export(home_team, match_ids=ids, include_upload_info=True)

    async def archive_cloud_reports(self, records: list[dict], query_team: str, source_url: str) -> dict:
        """完整抓取后原子UPSERT；云端ID唯一，不触碰matches/duels。"""
        def valid_date(value):
            try:
                return date.fromisoformat(str(value)).isoformat()
            except (ValueError, TypeError):
                return None
        rows = []
        seen = set()
        now = int(time.time())
        for record in records:
            raw_id = str(record.get('id', ''))
            if not re.fullmatch(r'[0-9]{1,20}', raw_id) or not 0 < int(raw_id) < 2**64:
                raise ValueError('云端战报编号无效。')
            cloud_id = int(raw_id)
            if cloud_id in seen:
                raise ValueError('本次抓取出现重复云端编号。')
            seen.add(cloud_id)
            body = record['body']
            data = dict(record, id=str(cloud_id))
            rows.append((cloud_id, str(data.get('team_a') or '')[:64], str(data.get('team_b') or '')[:64],
                         valid_date(data.get('match_time')), valid_date(data.get('publish_date')),
                         str(data.get('winner_site') or '')[:64], str(data.get('loser_site') or '')[:64],
                         str(data.get('publisher') or '')[:255], query_team, source_url, body,
                         json.dumps(data, ensure_ascii=False, allow_nan=False),
                         hashlib.sha256(body.encode('utf-8')).hexdigest(), now, now))
        inserted = refreshed = 0
        if not rows:
            return dict(total=0, inserted=0, refreshed=0)
        assert self.pool is not None
        async with self.pool.acquire() as conn:
            await conn.begin()
            try:
                async with conn.cursor() as cur:
                    for row in sorted(rows, key=lambda r: r[0]):
                        await cur.execute(
                            """INSERT INTO cloud_battle_reports
                               (cloud_id, team_a, team_b, match_time, publish_date, winner_site, loser_site,
                                publisher, query_team, source_url, body, parsed_json, content_hash, created_at, last_seen_at)
                               VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s) AS new
                               ON DUPLICATE KEY UPDATE team_a=new.team_a, team_b=new.team_b,
                               match_time=new.match_time, publish_date=new.publish_date,
                               winner_site=new.winner_site, loser_site=new.loser_site, publisher=new.publisher,
                               query_team=new.query_team, source_url=new.source_url, body=new.body,
                               parsed_json=new.parsed_json, content_hash=new.content_hash, last_seen_at=new.last_seen_at""", row)
                        if cur.rowcount == 1:
                            inserted += 1
                        else:
                            refreshed += 1
                await conn.commit()
            except BaseException:
                await conn.rollback()
                raise
        return dict(total=len(rows), inserted=inserted, refreshed=refreshed)

    async def get_cloud_reports(self, start: str, end: str, team: str, offset: int, limit: int, *, outcome: str = 'all') -> dict:
        where = 'COALESCE(match_time, publish_date) BETWEEN %s AND %s'
        params = [start, end]
        if team:
            where += ' AND (team_a=%s OR team_b=%s OR winner_site=%s OR loser_site=%s OR query_team=%s)'
            params += [team] * 5
        if outcome not in ('all', 'win', 'loss') or (outcome != 'all' and not team):
            raise ValueError('胜负筛选无效。')
        if outcome != 'all':
            where += " AND winner_site <> '' AND loser_site <> '' AND winner_site <> loser_site"
            where += ' AND winner_site = %s' if outcome == 'win' else ' AND loser_site = %s'
            params.append(team)
        count = await self._query('SELECT COUNT(*) AS n FROM cloud_battle_reports WHERE ' + where, tuple(params))
        rows = await self._query('SELECT * FROM cloud_battle_reports WHERE ' + where
                                 + ' ORDER BY cloud_id DESC LIMIT %s OFFSET %s', tuple(params + [limit, offset]))
        return dict(total=int(count[0]['n']), records=rows)

    async def get_cloud_reports_by_ids(self, ids: list[int]) -> list[dict]:
        if not ids:
            return []
        return await self._query('SELECT * FROM cloud_battle_reports WHERE cloud_id IN ('
                                 + ','.join(['%s'] * len(ids)) + ')', tuple(ids))

    async def get_dispatch_admin_teams(self) -> list[str]:
        rows = await self._query('SELECT DISTINCT home_team FROM team_admins ORDER BY home_team')
        return [row['home_team'] for row in rows]

    async def set_reports_export_sent_through(self, home_team: str, cutoff_id: int, sent: bool) -> int:
        """标记本队 ID≤截止 ID 的所有战报；截止战报必须存在且属于本队。

        不限月份、类型或数量，返回实际更新行数。重复操作不改变范围外状态。
        """
        if type(cutoff_id) is not int or not 0 < cutoff_id < 2**63:
            raise ValueError("截止战报 ID 无效喵。")
        assert self.pool is not None
        async with self.pool.acquire() as conn:
            await conn.begin()
            try:
                async with conn.cursor() as cur:
                    await cur.execute(
                        "SELECT id FROM matches WHERE home_team = %s AND id = %s FOR UPDATE",
                        (home_team, cutoff_id),
                    )
                    if await cur.fetchone() is None:
                        raise ValueError("截止战报不存在或不属于本战队喵。")
                    await cur.execute(
                        "UPDATE matches SET export_sent = %s WHERE home_team = %s AND id <= %s",
                        (int(sent), home_team, cutoff_id),
                    )
                    changed = cur.rowcount
                await conn.commit()
            except BaseException:
                await conn.rollback()
                raise
        return changed
