"""排表模块：解析战队名单 + 随机配对 + 生成战报模板（纯 Python，便于单测）。

输入格式（用户在命令后粘贴）::

    人头赛            <- 可选规则（也可以没有，用默认规则）
    a队:云玩家 萌新 遗老
    b队:复读机 鸽子 柠檬

生成战报模板（第一轮随机配对，比分 0:0 占位，第二轮留空）::

    战队: a队 VS b队
    时间: 2026.08.01
    规则: 人头赛
    地点: 435823386
    ------第一轮------
    云玩家  0:0  柠檬
    萌新  0:0  鸽子
    遗老  0:0  复读机
    ------第二轮------

一方人数较少时，缺人的位置以 TK 占位，由用户替换为实际玩家名。
"""

import random
import re
from dataclasses import dataclass, field

try:
    from .command_args import parse_command_args, single_name
except ImportError:
    from command_args import parse_command_args, single_name

try:
    # AstrBot 以包方式导入插件（data.plugins.<插件名>.main）
    from .battle_report_parser import (
        RAID_RE, ROUND_RE, RULE_RE, SCORE_RE, _BARE_DATE_RE, _cn_to_int,
        determine_match_winner, parse_battle_report,
    )
except ImportError:  # 单测以顶层模块导入
    from battle_report_parser import (
        RAID_RE, ROUND_RE, RULE_RE, SCORE_RE, _BARE_DATE_RE, _cn_to_int,
        determine_match_winner, parse_battle_report,
    )

try:
    from .stats import compute_raid_match
except ImportError:
    from stats import compute_raid_match

# 队伍行："a队:云玩家 遗老" / "a队：云玩家 遗老"
TEAM_LINE_RE = re.compile(r"^([^:：]+)\s*[:：]\s*(.+)$")

_CN_DIGITS = "零一二三四五六七八九"


@dataclass
class RosterResult:
    """名单解析结果。errors 非空表示排表失败。"""

    teams: list[tuple[str, list[str]]] = field(default_factory=list)  # [(队伍名, [成员])]
    rule: str = ""
    errors: list[str] = field(default_factory=list)


@dataclass
class GeneratedTemplate:
    """排表生成的模板与提示信息。"""

    template: str
    warnings: list[str] = field(default_factory=list)  # 如人数不匹配提示


def parse_lineup(text: str, default_rule: str) -> RosterResult:
    """解析名单文本。

    Args:
        text: 剥离命令词后的文本。首个非空行若不含"队伍名:"则为规则。
        default_rule: 未指定规则时使用的默认规则。

    Returns:
        RosterResult: errors 非空则排表失败。
    """
    result = RosterResult()
    errors: list[str] = []

    lines: list[str] = []
    for raw in text.splitlines():
        line = raw.rstrip().replace("　", " ").strip()
        if line:
            lines.append(line)
    if not lines:
        errors.append("喵…名单是空的喵，要写成『队伍名: 成员1 成员2』哦。")
        return RosterResult(errors=errors)

    rule_found = False
    for lineno, line in enumerate(lines, start=1):
        m = TEAM_LINE_RE.match(line)
        if not m:
            # 第一个非名单行视为规则（如 "/排表 人头赛" 剥离后首行是 "人头赛"）
            if lineno == 1 and not rule_found:
                result.rule = line.strip()
                rule_found = True
                continue
            errors.append(
                f"第 {lineno} 行喵：认不出这是队伍名单，"
                f"要写成『队伍名: 成员1 成员2』喵：{line}"
            )
            continue
        team_name = m.group(1).strip().upper()  # 队标含字母时统一转大写
        try:
            players = [arg.value for arg in parse_command_args(m.group(2), split_commas=True)]
        except ValueError as e:
            errors.append(f"第 {lineno} 行：{e}")
            continue
        if not team_name:
            errors.append(f"第 {lineno} 行喵：队伍名是空的喵：{line}")
            continue
        if not players:
            errors.append(f"第 {lineno} 行喵：队伍『{team_name}』一个成员都没有喵：{line}")
            continue
        result.teams.append((team_name, players))

    if not result.teams:
        errors.append("喵…一份战队名单都没解析出来喵。")

    if not rule_found:
        result.rule = default_rule

    result.errors = errors
    return result


def _format_date_dotted(iso_date: str) -> str:
    """ISO "YYYY-MM-DD" 转展示用的 "YYYY.MM.DD"（与用户模板一致）。"""
    parts = iso_date.split("-")
    if len(parts) == 3:
        return ".".join(parts)
    return iso_date


def generate_template(
    team_a: str,
    players_a: list[str],
    team_b: str,
    players_b: list[str],
    match_date: str,   # ISO "YYYY-MM-DD"
    rule: str,
    location: str,
    seed: str | None = None,
) -> GeneratedTemplate:
    """生成战报模板：第一轮随机配对（0:0 占位）+ 空第二轮。

    对局数 = 两队人数最大值；人数较少的一方超出其名单的位置以 TK 占位，
    由用户替换为实际玩家名（第二轮为第一轮胜者晋级，不属于补充位）。

    Args:
        match_date: 比赛日期，ISO "YYYY-MM-DD"。
        seed: 非空则固定随机种子（便于复现/测试）。
    """
    a = list(players_a)
    b = list(players_b)
    if seed:
        random.seed(seed)
    random.shuffle(a)
    random.shuffle(b)

    count = max(len(a), len(b))
    round1_lines = []
    for i in range(count):
        p_a = a[i] if i < len(a) else "TK"
        p_b = b[i] if i < len(b) else "TK"
        round1_lines.append(f"{p_a}  0:0  {p_b}")

    lines = [
        f"战队: {team_a} VS {team_b}",
        f"时间: {_format_date_dotted(match_date)}",
        f"规则: {rule}",
        f"地点: {location}",
        "------第一轮------",
        *round1_lines,
        "------第二轮------",
    ]

    return GeneratedTemplate(template="\n".join(lines), warnings=[])


# ---------- 追加轮次 ----------

@dataclass
class RoundBuildResult:
    """/第N轮 构建结果。"""

    ok: bool
    new_text: str
    added_lines: list[str]
    errors: list[str]


def parse_round_no(s: str) -> int | None:
    """解析轮次号（数字或中文），必须 >= 2（第 1 轮由排表生成），否则返回 None。"""
    n = _cn_to_int(s)
    if n is None or n < 2:
        return None
    return n


def _int_to_cn(n: int) -> str:
    """整数转中文数字（1-99）。"""
    if n <= 0:
        return str(n)
    if n < 10:
        return _CN_DIGITS[n]
    if n == 10:
        return "十"
    if n < 20:
        return "十" + _CN_DIGITS[n % 10]
    tens, ones = divmod(n, 10)
    return _CN_DIGITS[tens] + "十" + (_CN_DIGITS[ones] if ones else "")


def _find_round_index(lines: list[str], round_no: int) -> int | None:
    """在草稿行中定位第 round_no 轮的段头行号。"""
    for i, ln in enumerate(lines):
        m = ROUND_RE.match(ln)
        if m and _cn_to_int(m.group(1)) == round_no:
            return i
    return None


def _append_round(draft_text: str, round_no: int, lines: list[str]) -> str:
    """把第 round_no 轮的对局行追加进草稿（已有该段则插入，否则在末尾新建）。"""
    out = draft_text.splitlines()
    idx = _find_round_index(out, round_no)
    if idx is not None:
        insert_at = idx + 1
        while insert_at < len(out) and not ROUND_RE.match(out[insert_at]):
            insert_at += 1
        out[insert_at:insert_at] = lines
        return "\n".join(out).rstrip() + "\n"
    block = [f"------第{_int_to_cn(round_no)}轮------"] + lines
    return "\n".join(out + [""] + block).rstrip() + "\n"


def build_next_round(
    draft_text: str,
    round_no: int,
    info_lines: list[str],
    seed: str | None = None,
) -> RoundBuildResult:
    """在战报草稿上追加第 round_no 轮。

    无 info_lines 时：从上一轮与本轮的空闲存活选手中随机配对。
    未结束对局的双方暂不参与；本轮胜者可继续匹配，败者或非零平分双方淘汰。
    两队各自洗牌后按索引配对，不补 TK 占位。
    有 info_lines 时：每行『玩家A』『玩家B』或『玩家A 比分 玩家B』追加为对局；
    比分可写冒号形式（2:0）或紧凑两位数字形式（20 表示 2:0）。
    """
    errors: list[str] = []
    parsed = parse_battle_report(draft_text)
    if parsed.errors:
        return RoundBuildResult(
            False, draft_text, [],
            ["喵…当前战报解析不了喵：\n" + "\n".join(parsed.errors)],
        )
    report = parsed.report

    prev_round = max((d.round_no for d in report.duels if d.round_no < round_no), default=None)
    if prev_round is None:
        return RoundBuildResult(
            False, draft_text, [],
            [f"喵…没找到第 {round_no} 轮之前的轮次喵，先把上一轮打完嘛。"],
        )

    if not info_lines:
        # 按轮次及对局顺序更新最后状态，避免赢过但随后淘汰的选手重新入池。
        # 两队分别记录，既去重，也不会混淆对手战队的同名 ID。
        alive_a: dict[str, bool] = {}
        alive_b: dict[str, bool] = {}
        pending_a: set[str] = set()
        pending_b: set[str] = set()
        has_result = False
        for current_round in (prev_round, round_no):
            for d in report.duels:
                if d.round_no != current_round:
                    continue
                if d.score_a == 0 and d.score_b == 0:
                    pending_a.add(d.player_a)
                    pending_b.add(d.player_b)
                    continue
                has_result = True
                alive_a[d.player_a] = d.score_a > d.score_b
                alive_b[d.player_b] = d.score_b > d.score_a
        if not has_result:
            return RoundBuildResult(
                False, draft_text, [],
                [f"喵…第 {prev_round} 轮还没分出胜者，请先填写比分。"],
            )
        a = [name for name, alive in alive_a.items() if alive and name not in pending_a]
        b = [name for name, alive in alive_b.items() if alive and name not in pending_b]
        if seed:
            random.seed(seed)
        random.shuffle(a)
        random.shuffle(b)
        # 只配对双方实际胜者（TK 占位仅用于 /排表，不在追加轮次出现）
        count = min(len(a), len(b))
        added = [f"{a[i]}  0:0  {b[i]}" for i in range(count)]
        if not added:
            return RoundBuildResult(
                False, draft_text, [],
                ["喵…暂时没有可配对的选手。"
                 + ("请先完成未结束的对局喵。" if pending_a or pending_b else "")],
            )
    else:
        # 玩家→队伍映射（左=team_a，右=team_b），用于按队伍对齐对局顺序
        team_map = {}
        for d in report.duels:
            team_map.setdefault(d.player_a, report.team_a)
            team_map.setdefault(d.player_b, report.team_b)
        team_a = report.team_a

        added = []
        for line in info_lines:
            line = line.strip()
            if not line:
                continue
            m = SCORE_RE.search(line)
            if m:
                sa, sb = int(m.group(1)), int(m.group(2))
                try:
                    pa = single_name(line[: m.start()])
                    pb = single_name(line[m.end():])
                except ValueError as e:
                    errors.append(str(e))
                    continue
                if not pa or not pb:
                    errors.append(f"喵…这行对局解析不了喵：{line}")
                    continue
            else:
                try:
                    parts = [arg.value for arg in parse_command_args(line)]
                except ValueError as e:
                    errors.append(str(e))
                    continue
                if len(parts) == 2:
                    pa, pb = parts[0], parts[1]
                    sa = sb = 0
                elif len(parts) == 3 and len(parts[1]) == 2 and parts[1].isdigit():
                    # 紧凑比分：20 → 2:0（KOF 每局比分不超过两位数字）
                    pa, pb = parts[0], parts[2]
                    sa, sb = int(parts[1][0]), int(parts[1][1])
                else:
                    errors.append(
                        f"喵…这行对局解析不了喵：{line}"
                        f"\n用法：玩家A 玩家B，或 玩家A 比分 玩家B。"
                    )
                    continue
            if team_a:
                pa, sa, pb, sb = _align_team_order(pa, sa, pb, sb, team_map, team_a)
            added.append(f"{pa}  {sa}:{sb}  {pb}")
        if errors and not added:
            return RoundBuildResult(False, draft_text, [], errors)
        if not added:
            return RoundBuildResult(False, draft_text, [], ["喵…没有能加进去的对局喵。"])

    new_text = _append_round(draft_text, round_no, added)
    return RoundBuildResult(True, new_text, added, errors)


# ---------- 记录比分（/记录） ----------

@dataclass
class RecordResult:
    """/记录 结果。"""

    ok: bool
    new_text: str
    added_lines: list[str]
    errors: list[str]


def parse_score_token(s: str) -> tuple[int, int] | None:
    """解析比分 token："2:0" 或紧凑两位数字 "20" → (2, 0)。"""
    s = s.strip()
    m = re.match(r"^(\d+)\s*[:：]\s*(\d+)$", s)
    if m:
        return int(m.group(1)), int(m.group(2))
    if len(s) == 2 and s.isdigit():
        return int(s[0]), int(s[1])
    return None


def _scan_duel_lines(lines: list[str]) -> list[tuple[int, int, str, int, int, str]]:
    """扫描草稿行，返回对局列表 [(行号, 轮次, 玩家A, 比分A, 比分B, 玩家B)]。"""
    result: list[tuple[int, int, str, int, int, str]] = []
    round_no = 0
    for i, ln in enumerate(lines):
        m = ROUND_RE.match(ln)
        if m:
            round_no = _cn_to_int(m.group(1)) or (round_no + 1)
            continue
        m = SCORE_RE.search(ln)
        if m:
            pa = ln[: m.start()].strip()
            pb = ln[m.end():].strip()
            if pa and pb:
                sa, sb = int(m.group(1)), int(m.group(2))
                result.append((i, round_no, pa, sa, sb, pb))
    return result


def _parse_teams_and_mapping(draft_text: str) -> tuple[str | None, str | None, dict]:
    """解析草稿的战队信息与 玩家→队伍 映射（左=team_a，右=team_b）。"""
    parsed = parse_battle_report(draft_text)
    if parsed.errors or not parsed.report:
        return None, None, {}
    report = parsed.report
    mapping: dict[str, str] = {}
    for d in report.duels:
        mapping.setdefault(d.player_a, report.team_a)
        mapping.setdefault(d.player_b, report.team_b)
    return report.team_a, report.team_b, mapping


def _align_team_order(
    p1: str, s1: int, p2: str, s2: int,
    team_map: dict, team_a: str,
) -> tuple[str, int, int, str]:
    """按队伍对齐对局：team_a（战队头左侧）的选手放左侧。

    若 p2 属于 team_a 而 p1 不属于，则交换双方与比分。无法确认归属时保持原样。
    """
    t1 = team_map.get(p1)
    t2 = team_map.get(p2)
    if t2 == team_a and t1 != team_a:
        return p2, s2, p1, s1
    return p1, s1, p2, s2


def record_result(
    draft_text: str,
    player: str,
    my_score: int,
    opp_score: int,
    opponent: str | None = None,
) -> RecordResult:
    """在草稿中记录一名选手的比分。

    - opponent 为 None：寻找该选手最后一场未记录比分（0:0）的对阵并填入比分；
      找不到则报错。
    - opponent 给定：先按上一条逻辑尝试填入；若无未记录对阵，则在最新轮次
      插入新对阵『player my_score:opp_score opponent』。
    """
    lines = draft_text.splitlines()
    duels = _scan_duel_lines(lines)

    # 最后一场未记录比分且含该选手的对阵
    target = None
    for i, _, pa, sa, sb, pb in reversed(duels):
        if sa == 0 and sb == 0 and (pa == player or pb == player):
            target = (i, pa, pb, pa == player)
            break

    if target:
        line_idx, pa, pb, player_is_a = target
        if player_is_a:
            new_line = f"{pa}  {my_score}:{opp_score}  {pb}"
        else:
            # 选手在右侧：保持左侧玩家不变，右侧填选手比分
            new_line = f"{pa}  {opp_score}:{my_score}  {pb}"
        lines[line_idx] = new_line
        new_text = "\n".join(lines).rstrip() + "\n"
        return RecordResult(True, new_text, [new_line], [])

    if opponent is None:
        return RecordResult(
            False, draft_text, [],
            [f"喵…没找到「{player}」待记录比分的对阵呢。"],
        )

    # 无未记录对阵 → 在最新轮次插入新对阵（按队伍对齐：team_a 选手在左）
    latest_round = 0
    for ln in lines:
        m = ROUND_RE.match(ln)
        if m:
            latest_round = max(latest_round, _cn_to_int(m.group(1)) or latest_round + 1)
    if latest_round == 0:
        return RecordResult(False, draft_text, [], ["喵…这份草稿里没有能用的轮次喵。"])

    team_a, _, team_map = _parse_teams_and_mapping(draft_text)
    p1, s1, p2, s2 = player, my_score, opponent, opp_score
    if team_a:
        p1, s1, p2, s2 = _align_team_order(p1, s1, p2, s2, team_map, team_a)
    new_line = f"{p1}  {s1}:{s2}  {p2}"
    new_text = _append_round(draft_text, latest_round, [new_line])
    return RecordResult(True, new_text, [new_line], [])


def record_from_info(draft_text: str, info: str) -> RecordResult:
    """根据记录信息行（如『随便 20』或『随便 20 黄大』）在草稿中记录比分。"""
    try:
        tokens = [arg.value for arg in parse_command_args(info)]
    except ValueError as e:
        return RecordResult(False, draft_text, [], [str(e)])
    if len(tokens) == 2:
        player, score_token = tokens
        score = parse_score_token(score_token)
        if score is None:
            return RecordResult(
                False, draft_text, [], [f"喵…这个比分看不懂喵：{score_token}"]
            )
        return record_result(draft_text, player, score[0], score[1], None)
    if len(tokens) == 3:
        player, score_token, opponent = tokens
        score = parse_score_token(score_token)
        if score is None:
            return RecordResult(
                False, draft_text, [], [f"喵…这个比分看不懂喵：{score_token}"]
            )
        return record_result(draft_text, player, score[0], score[1], opponent)
    return RecordResult(
        False, draft_text, [],
        [f"喵…记录要写成『玩家名 比分 [对手]』喵，收到的却是：{info}"],
    )


def format_duel_results(report, home_team: str) -> str:
    """每场对阵结果（主体战队视角），供提交后核对。

    格式：第一轮 玩家 比分 vs 对手 ✅ 胜 / ❌ 负 / ➖ 平。
    玩家 ID 一律显示干净 ID（替补由 duels.a_sub/b_sub 标志记录，不在核对信息中标出）。
    """
    home = home_team if home_team in (report.team_a, report.team_b) else report.team_a
    lines = []
    for d in report.duels:
        if home == report.team_b:
            hp, hs, os_, op = d.player_b, d.score_b, d.score_a, d.player_a
        else:
            hp, hs, os_, op = d.player_a, d.score_a, d.score_b, d.player_b
        if hs > os_:
            mark = "✅ 胜"
        elif hs < os_:
            mark = "❌ 负"
        else:
            mark = "➖ 平"
        lines.append(
            f"第{_int_to_cn(d.round_no)}轮 {hp} {hs}:{os_} vs {op} {mark}"
        )
    return "\n".join(lines)


def format_raid_results(report, home_team: str) -> str:
    """踢馆战报的对局结果回执（提交后核对用）。

    每行的对错标记**按提交方战队的视角**给（`home_team` 是本群绑定的战队）：

    - 本群是踢馆方（`team_a`）→ `萌新 2:1 云玩家 ✅ 进攻成功` / `❌ 进攻失败`
    - 本群是守馆方（`team_b`）→ `萌新 2:1 云玩家 ❌ 防守失败` / `✅ 防守成功`

    比分恒为 `踢馆方:守馆方`（左侧永远是踢馆者），只有措辞跟着视角走。
    末尾附一行结论，**结论行同样按提交方视角**（踢馆方看到「踢馆成功 / 踢馆失败」，
    守馆方看到「守馆成功 / 守馆失败」），并附防守者人数与是否含馆主、踢破时的加点。

    计数（防守者人数/是否含馆主/首轮）与点数一律走 `stats.compute_raid_match`，
    这里不重复实现一份判定。
    """
    info = compute_raid_match(
        [
            {
                "seq": i,
                "score_a": d.score_a,
                "score_b": d.score_b,
                "player_b": d.player_b,
                "owner": d.owner,
                "resolved_a": d.player_a,
                "resolved_b": d.player_b,
            }
            for i, d in enumerate(report.duels)
        ],
        determine_match_winner(report) or "",
        report.team_a,
        report.team_b,
    )

    # 视角 = 提交方战队：本群是守馆方就看右侧，否则看左侧（main.py 已保证
    # home_team 必为 team_a / team_b 之一，所以「不是守馆方」即踢馆方）。
    i_defend = home_team == report.team_b
    ok_mark, bad_mark = ("✅ 防守成功", "❌ 防守失败") if i_defend else ("✅ 进攻成功", "❌ 进攻失败")

    lines = []
    for d in report.duels:
        mine, theirs = (d.score_b, d.score_a) if i_defend else (d.score_a, d.score_b)
        if mine > theirs:
            mark = ok_mark
        elif theirs > mine:
            mark = bad_mark
        else:
            mark = "➖ 未打"
        pb = d.player_b + ("(馆主)" if d.owner else "")
        lines.append(f"{d.player_a} {d.score_a}:{d.score_b} {pb} {mark}")

    # 结论行**也按提交方视角**，与上面那批 ✅/❌ 同一套方向。
    # ⚠️ 这行曾经恒用守馆方措辞（`🛡️ 守馆成功（team_b）`），于是踢馆失败的战队
    # 会在自己群里看到**对手**的守馆成功 —— 和上面跟随视角的对局标记自相矛盾。
    # 反过来，守馆方被踢穿时也会看到「⚔️ 踢馆成功（防守者5人）」，像是自己赢了。
    defenders = f"防守者{info['defender_count']}人"
    if info["has_owner"]:
        defenders += "，含馆主"
    if info["raider_success"]:
        if i_defend:
            verdict = f"💀 守馆失败（{report.team_b}），{defenders}"
        else:
            verdict = f"⚔️ 踢馆成功（{defenders}），踢馆积分+{info['attack_points']}"
    elif info["hold"]:
        if i_defend:
            verdict = f"🛡️ 守馆成功（{report.team_b}），{defenders}"
        else:
            verdict = f"💀 踢馆失败（{report.team_a}），{defenders}"
    else:
        verdict = "⚠️ 胜负未定，暂不计算积分"
    lines.append(verdict)
    return "\n".join(lines)


def format_duels_block(duels: list[dict]) -> str:
    """对局段（含轮次分隔），对阵行双空格：`玩家A  比分  玩家B`，替补补 (替)、判罚补 (规则)、馆主补 (馆主)。

    踢馆报的对局 `round_no` 恒为 0（没有轮次概念），此时**不输出轮次头**。
    """
    rounds: dict[int, list[dict]] = {}
    for d in duels:
        rounds.setdefault(d["round_no"], []).append(d)
    lines = []
    for round_no in sorted(rounds):
        if round_no != 0:  # 踢馆报无轮次（round_no=0）
            lines.append(f"------第{_int_to_cn(round_no)}轮------")
        for d in rounds[round_no]:
            pa = d["player_a"]
            if d.get("a_sub"):
                pa += "(替)"
            pb = d["player_b"]
            if d.get("b_sub"):
                pb += "(替)"
            if d.get("owner"):
                pb += "(馆主)"  # 踢馆赛：馆主标记只认防守方（右侧）
            if d.get("ruled"):
                # 判罚方比分更低，为败方 → 给败方 ID 补 (规则)
                if d["score_a"] < d["score_b"]:
                    pa += "(规则)"
                elif d["score_b"] < d["score_a"]:
                    pb += "(规则)"
            lines.append(f"{pa}  {d['score_a']}:{d['score_b']}  {pb}")
    return "\n".join(lines)


def format_report(
    team_a: str, team_b: str, match_time: str, rule: str, location: str,
    duels: list[dict],
) -> str:
    """从结构化字段还原战报文本（raw_text 缺失时的兜底路径）。

    duels 为按 seq 排序的对局 dict 列表（round_no/player_a/score_a/player_b/score_b）。
    按轮次分组输出，对阵行双空格，顺序与输入一致。
    """
    lines = [
        f"战队: {team_a} VS {team_b}",
        f"时间: {match_time}",
        f"规则: {rule}",
        f"地点: {location}",
    ]
    body = format_duels_block(duels)
    return "\n".join(lines) + (("\n" + body) if body else "")


def is_raid_duel_line(line: str) -> bool:
    """该行是否是一条踢馆对局行（`云玩家 2:1 路人乙(馆主)`）。

    必须排除规则行与裸时间行：`规则：OCG.2026.7.1.MATCH` 与 `2026.8.30 21:00`
    都含冒号数字，会被 `SCORE_RE` 误命中。
    """
    s = line.strip()
    if not s or RULE_RE.match(s) or _BARE_DATE_RE.match(s):
        return False
    return bool(SCORE_RE.search(s))


def _header_block(raw: str) -> str:
    """取原始文本中第一个轮次分隔符之前的头部行（战队/时间/规则/地点）。

    踢馆战报没有轮次分隔符，改用**第一条对局行**作分界（头部 = 首行到
    `踢馆开始！`，含）。不这么切的话导出会把对局行输出两遍：头部原样保留
    一份，`format_duels_block` 又重建一份。
    """
    lines = raw.split("\n")
    if lines and RAID_RE.match(lines[0].strip()):
        for i, ln in enumerate(lines):
            if is_raid_duel_line(ln):
                return "\n".join(lines[:i])
        return raw.strip()
    for i, ln in enumerate(lines):
        if ROUND_RE.match(ln):
            return "\n".join(lines[:i])
    return raw.strip()


def report_to_text(r: dict) -> str:
    """生成单份战报的导出文本。

    raw_text 存在时头部逐字保留（时间格式等不变），对局段按双空格重建，保证
    『参赛ID与比分间为两个空格』；raw_text 缺失时全量结构化兜底。
    """
    body = format_duels_block(r["duels"])
    if r["raw_text"]:
        head = _header_block(r["raw_text"])
        return (head + "\n" + body) if head else body
    return format_report(
        r["team_a"], r["team_b"], r["match_time"], r["rule"], r["location"], r["duels"]
    )


def _player_side(r: dict, players: set[str], member_team: str | None = None) -> str | None:
    """玩家（参赛ID集合）在该场对局中出现的侧（team_a/team_b）。

    未参与返回 None；两侧都出现（异常数据）无法判定也返回 None。
    member_team 非空时要求该玩家在 member_team 一侧出场（跨队同名——如两队都有同名
    玩家——不归入本战队成员，返回 None）。
    """
    side = None
    for d in r["duels"]:
        if d["player_a"] in players:
            if side is not None and side != r["team_a"]:
                return None
            side = r["team_a"]
        if d["player_b"] in players:
            if side is not None and side != r["team_b"]:
                return None
            side = r["team_b"]
    if side is None:
        return None
    if member_team and side != member_team:
        return None  # 跨队同名：非本战队一侧出场，不计入本战队成员
    return side


def _player_has_duel_result(r: dict, players: set[str], want_win: bool) -> bool:
    """玩家本人是否存在胜利(want_win=True)/失败(want_win=False)对局。

    按对局比分判定（0:0 未完结对局不计入任何一方）。调用方已通过 _player_side
    保证玩家侧一致且（member_team 指定时）在本队一侧出场。
    """
    for d in r["duels"]:
        if d["player_a"] in players:
            if want_win and d["score_a"] > d["score_b"]:
                return True
            if not want_win and d["score_b"] > d["score_a"]:
                return True
        if d["player_b"] in players:
            if want_win and d["score_b"] > d["score_a"]:
                return True
            if not want_win and d["score_a"] > d["score_b"]:
                return True
    return False


def filter_report_outcome(
    reports: list[dict],
    outcome: str,
    players: list[str] | None = None,
    member_team: str | None = None,
) -> list[dict]:
    """按导出范围过滤战报聚合 dict 列表。

    players 为空时以主体战队 home_team 为参照（现有语义）：
    - 全部：不过滤
    - 胜场：matches.winner == matches.home_team（主体战队获胜）
    - 负场：主体战队在对阵内且胜负已定且 winner != home_team（主体战队战败）
    主体不在对阵内或胜负未定的，胜/负过滤中排除。

    players 非空时（指定某玩家）仅保留该玩家参与的对阵，胜/负以该玩家本人
    对局结果判定（选手级口径，不再看整场胜负）：
    - 全部：仅按玩家参与过滤
    - 胜场：该玩家本人存在胜利对局（个人有赢的比赛）
    - 负场：该玩家本人存在失败对局（个人有输的比赛）
    同一场可能同时命中胜场与负场（个人有赢也有输）。玩家未参与或两侧都出现的
    对阵在过滤中排除。

    member_team 非空时（该玩家是 member_team 的已绑定成员）额外要求玩家在
    member_team 一侧出场：跨队同名玩家（如对方战队也有同名参赛ID）不归入本队。
    """
    pset = set(players) if players else None
    result = []
    for r in reports:
        if pset:
            if _player_side(r, pset, member_team) is None:
                continue  # 玩家未参与，或两侧都出现/跨队同名无法判定
            if outcome != "胜场" and outcome != "负场":
                result.append(r)  # 全部：仅按玩家参与过滤
            elif outcome == "胜场":
                if _player_has_duel_result(r, pset, want_win=True):
                    result.append(r)
            else:  # 负场
                if _player_has_duel_result(r, pset, want_win=False):
                    result.append(r)
        else:
            home = r["home_team"] or ""
            in_match = home in (r["team_a"], r["team_b"])
            winner = r["winner"] or ""
            if outcome != "胜场" and outcome != "负场":
                result.append(r)  # 全部：不过滤
            elif outcome == "胜场":
                if home and winner == home:
                    result.append(r)
            else:  # 负场
                if home and in_match and winner and winner != home:
                    result.append(r)
    return result
